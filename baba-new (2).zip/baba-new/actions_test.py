from typing import Any, Text, Dict, List
from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher
from rasa.core.events import UserUttered
import requests
import redis
import json

r = redis.Redis(host='localhost', port=6379, db=0)

class ActionHelloWorld(Action):
    def name(self) -> Text:
        return "action_hello_world"
    def run(self, dispatcher: CollectingDispatcher,
           tracker: Tracker,
           domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
#
        dispatcher.utter_message(text="Hello World!")

        return []

class ActionLanguageChange(Action):
    def name(self) -> Text:
        return "action_language_change"
    def run(self, dispatcher: CollectingDispatcher,
           tracker: Tracker,
           domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        lang = r.get(tracker.sender_id)
        if lang == "ENGLISH":
            r.set(tracker.sender_id, "ENGLISH")
        elif lang == "ARABIC":
            r.set(tracker.sender_id, "ARABIC")
        else: 
            r.set(tracker.sender_id, "ENGLISH")

        url = "0.0.0.0:5001/action"
        data = {"sender": tracker.sender_id, "message":"#"}
        j = requests.post(url, json.dumps(data))
        dispatcher.utter_message(text="Alright.")

        return []

class ActionWeather(Action):
    def name(self) -> Text:
        return "action_check_weather"
    async def run(self, dispatcher: CollectingDispatcher,
           tracker: Tracker,
           domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        
        api_key = "c96f987672f311acf95477ad9a1276c5"
        city_name = tracker.get_slot("City")
        base_url = "http://api.openweathermap.org/data/2.5/weather?"
        complete_url = base_url + "appid=" + api_key + "&q=" + city_name 
        response = requests.get(complete_url) 
        x = response.json() 
        dispatcher.utter_message(text="Alright.")
        if x["cod"] != "404": 
  
            # store the value of "main" 
            # key in variable y 
            y = x["main"] 
        
            # store the value corresponding 
            # to the "temp" key of y 
            current_temperature = y["temp"] 
        
            # store the value corresponding 
            # to the "pressure" key of y 
            current_pressure = y["pressure"] 
        
            # store the value corresponding 
            # to the "humidity" key of y 
            current_humidiy = y["humidity"] 
        
            # store the value of "weather" 
            # key in variable z 
            z = x["weather"] 
        
            # store the value corresponding  
            # to the "description" key at  
            # the 0th index of z 
            weather_description = z[0]["description"] 
            out = (" Temperature (in kelvin unit) = " +
                            str(current_temperature) + 
                "\n atmospheric pressure (in hPa unit) = " +
                            str(current_pressure) +
                "\n humidity (in percentage) = " +
                            str(current_humidiy) +
                "\n description = " +
                            str(weather_description)) 
            dispatcher.utter_custom_message(out)
  
        return []