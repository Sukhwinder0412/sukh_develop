import datetime
import mongoengine


class Action(mongoengine.Document):
    registered_date = mongoengine.DateTimeField(default=datetime.datetime.now)
    name = mongoengine.StringField(required=True)

    meta = {
        'collection': 'actions'
    }
