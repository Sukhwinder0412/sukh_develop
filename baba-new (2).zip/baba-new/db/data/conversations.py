import datetime
import mongoengine


class Conversation(mongoengine.Document):
    latest_input_channel = mongoengine.StringField()
    active_form = mongoengine.DictField()
    latest_event_time = mongoengine.DateTimeField()
    followup_action = mongoengine.StringField()
    sender_id = mongoengine.StringField()
    paused = mongoengine.BooleanField()
    latest_message  = mongoengine.DictField()
    slots  = mongoengine.DictField()
    events = mongoengine.ListField()
    latest_action_name = mongoengine.StringField()
    # registered_date = mongoengine.DateTimeField(default=datetime.datetime.now)
    # name = mongoengine.StringField(required=True)

    meta = {
        'collection': 'conversations'
    }
