import datetime
import mongoengine


class Entity(mongoengine.Document):
    registered_date = mongoengine.DateTimeField(default=datetime.datetime.now)
    name = mongoengine.StringField(required=True)

    meta = {
        'collection': 'entities'
    }
