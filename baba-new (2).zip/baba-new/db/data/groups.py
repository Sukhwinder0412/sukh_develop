import datetime
import mongoengine


class Group(mongoengine.Document):
    registered_date = mongoengine.DateTimeField(default=datetime.datetime.now)
    name = mongoengine.StringField(required=True)
    stories = mongoengine.ListField()
    status = mongoengine.BooleanField(default=True)
    partial_training = mongoengine.BooleanField(default=False)

    meta = {
        'collection': 'groups'
    }
