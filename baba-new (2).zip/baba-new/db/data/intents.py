import datetime
import mongoengine


class Intent(mongoengine.Document):
    registered_date = mongoengine.DateTimeField(default=datetime.datetime.now)
    name = mongoengine.StringField(required=True)
    text = mongoengine.ListField()
    in_stories = mongoengine.ListField()
    synonyms = mongoengine.ListField()
    entities = mongoengine.ListField()

    meta = {
        'collection': 'intents'
    }