import datetime
import mongoengine


class Language(mongoengine.Document):
    registered_date = mongoengine.DateTimeField(default=datetime.datetime.now)
    name = mongoengine.StringField(required=True)
    code = mongoengine.StringField(required=True)
    port = mongoengine.IntField(required=True)

    meta = {"collection": "languages"}
