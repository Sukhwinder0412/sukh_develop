import urllib
from mongoengine import connect, disconnect


def global_init(channel, alias):
    disconnect(alias=alias)
    username = urllib.parse.quote_plus("baba")
    password = urllib.parse.quote_plus("Qwerty123")
    host = f"mongodb+srv://{username}:{password}@baba.6fxcw.mongodb.net/{channel}?retryWrites=true&w=majority"
    # host = (
    #     f"mongodb+srv://{username}:{password}@baba.6fxcw.mongodb.net/test?retryWrites=true&w=majority"
    #     if channel == "admisn" or "confsig"
    #     else f"mongodb+srv://{username}:{password}@baba.6fxcw.mongodb.net/{channel}?retryWrites=true&w=majority",
    # )
    connect(
        alias=alias,
        db=channel,
        username=username,
        password=password,
        authentication_source="root",
        host=host,
    )


# import mongoengine
# global_init("Configurations", alias="config")

# def global_init():
#     mongoengine.register_connection(alias='core', name='bot_english')
