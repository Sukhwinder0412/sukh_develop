import datetime
import mongoengine


class Config(mongoengine.Document):
    # meta = {"db_alias": "config"}
    registered_date = mongoengine.DateTimeField(default=datetime.datetime.now)
    name = mongoengine.StringField(required=True)
    content = mongoengine.DictField(required=True)

    meta = {"collection": "settings", "db_alias": "config"}
