import datetime
import mongoengine


class Regex(mongoengine.Document):
    registered_date = mongoengine.DateTimeField(default=datetime.datetime.now)
    name = mongoengine.StringField(required=True)
    text = mongoengine.StringField(required=True)
    # in_stories = mongoengine.ListField()

    meta = {"collection": "regex"}
