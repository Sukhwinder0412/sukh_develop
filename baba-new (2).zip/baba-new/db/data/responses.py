import datetime
import mongoengine


class Response(mongoengine.Document):
    registered_date = mongoengine.DateTimeField(default=datetime.datetime.now)
    name = mongoengine.StringField(required=True)
    text = mongoengine.ListField()

    # buttons = mongoengine.ListField()
    in_stories = mongoengine.ListField()
    responsetype = mongoengine.StringField()
    # images = mongoengine.ListField()

    meta = {
        'collection': 'responses'
    }
