import datetime
import bson
import mongoengine


class Slot(mongoengine.Document):
    registered_date = mongoengine.DateTimeField(default=datetime.datetime.now)
    name = mongoengine.StringField(required=True)
    typename = mongoengine.StringField(required=True)
    initial_value = mongoengine.StringField()
    categories = mongoengine.ListField()
    min_value = mongoengine.StringField()
    max_value = mongoengine.StringField()

    meta = {
        'collection': 'slots'
    }
