import datetime
import mongoengine


class Story(mongoengine.Document):
    registered_date = mongoengine.DateTimeField(default=datetime.datetime.now)
    name = mongoengine.StringField(required=True)
    group = mongoengine.StringField(required=True)
    content = mongoengine.DictField()
    intents = mongoengine.ListField()
    responses = mongoengine.ListField()
    actions = mongoengine.ListField()
    slots = mongoengine.ListField()
    

    meta = {
        'collection': 'stories'
    }
