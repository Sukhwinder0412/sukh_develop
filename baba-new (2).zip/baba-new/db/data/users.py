import datetime
import mongoengine

# from flask_wtf import FlaskForm
# from wtforms import StringField, PasswordField, validators


class User(mongoengine.Document):
    registered_date = mongoengine.DateTimeField(default=datetime.datetime.now)
    email = mongoengine.EmailField(required=True)
    username = mongoengine.StringField(required=True, max_length=30)
    password = mongoengine.StringField(required=True)
    role     = mongoengine.StringField(required=True)
    meta = {"db_alias": "config", "collection": "users"}
