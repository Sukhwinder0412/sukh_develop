import bson
# import mongoengine
import data.mongo_setup as mongo_setup
import services.intent_service as intent_svc
import services.response_service as response_svc
import services.story_service as story_svc
import services.group_service as group_svc


def main():
    mongo_setup.global_init()
    # intents = svc.get_intents()
    # print(intents)
    name = input("enter story name name: ").lower()
    # intent = svc.delete_intent(name)
    # if intent:
    #     print("oh")
    # old_intent = intent_svc.find_intent_by_name(name)
    # print(old_intent.id)
    # intent = intent_svc.get_intent_by_id(old_intent.id)
    # print(intent)
    # if old_intent:
    #     print(f"ERROR: Intent with name {name} already exists.")
    #     return
    # text = [item for item in input("Enter the list of text : ").split()]
    # canonical = text[0]
    # intent = svc.del_canonical(name)
    # print(canonical)
    group = "test"
    content = {
        "main": {
            "intent": "greet",
            "response": "utter_greet"
        }
    }
    text = [{"data": "yoo bas", "canonical": False}]
    buttons = [{"title": "hello", "payload": "/greet"},
               {"title": "bye", "payload": "/goodbye"}]
    id1 = "5f22adb78d22d0f3b172dca9"
    images = ["http://sample.com/1.png"]
    # intent = intent_svc.update_intent(id1, name, text, synonyms=[], in_stories= [], entities= {},slots=[])
    # intent = intent_svc.create_intent(name, text)
    # intent = response_svc.create_response(name, text)
    # intent = response_svc.update_response(
    #     id1, name, text, images=images,  buttons=buttons)
    content = {
        "branch_name": "main",
        "story": [
            "greet",
            "utter_greet"
        ],
        "branches": [
            {
                "branch_name": "yes",
                "story": [
                    "yes",
                    "utter_yes",
                    "why",
                    "utter_why"
                ],
                "branches": [
                    {
                        "branch_name": "yes",
                        "story": [
                            "yes",
                            "utter_yes",
                            "why",
                            "utter_why"
                        ]
                    },
                    {
                        "branch_name": "No",
                        "story": [
                            "No",
                            "utter_no",
                            "why",
                            "utter_why"
                        ]
                    }
                ]
            },
            {
                "branch_name": "No",
                "story": [
                    "No",
                    "utter_no",
                    "why",
                    "utter_why"
                ]
            }
        ]
    }
    # intent = story_svc.create_story(name="story1", group="test", content=content)
    group = group_svc.create_group(name ="group1", stories=["story1"])
    # intent = intent_svc.get(name, text)
    # intent = intent_svc.get_all_intents()u
    # for x in intent:
    #     print (x.name)
    # print(intent)
    # try:
    #     print(f'Register new intent with id {intent.id}.')
    # except:
    #     pass


if __name__ == '__main__':
    main()
