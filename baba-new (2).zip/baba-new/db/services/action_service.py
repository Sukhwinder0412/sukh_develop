import bson
from db.data.actions import Action


def get_all_actions() -> Action:
    actions = Action.objects()
    
    return actions


def add_action(name:str) -> Action:
    prev_action = Action.objects(name=name).all()
    if prev_action:
        return "Error! Action already exists!"
    action = Action()
    action.name = name

    action.save()
    return action
# def find_entity_by_name(name: str) -> Entity:
#     entity = Entity.objects(name=name).first()
#     return entity


def delete_action(id: str) -> Action:
    action = Action.objects(id=id).all()
    action.delete()
    return f"Deleted!"

# add_action(name="action_language_change")

# def update_entity(id:str, name:str) -> Entity:
#     entity = Entity.objects(id=id).first()
#     entity.name = name

#     entity.save()
#     return entity



# def get_entity_by_id(id) -> Entity:
#     entity = Entity.objects(id=id).first()

#     return entity
# import bson
# from db.data.entities import Entity


# def add_entity(name:str) -> Entity:
#     prev_entity = Entity.objects(name=name).all()
#     if prev_entity:
#         return {"success":True}
#     entity = Entity()
#     entity.name = name

#     entity.save()
#     return {"success":True}


# def find_entity_by_name(name: str) -> Entity:
#     entity = Entity.objects(name=name).first()
#     return entity


# def delete_entity(id: str) -> Entity:
#     entity = Entity.objects(id=id).all()
#     entity.delete()
#     return f"Deleted!"


# def update_entity(id:str, name:str) -> Entity:
#     entity = Entity.objects(id=id).first()
#     entity.name = name

#     entity.save()
#     return entity


# def get_all_entities() -> Entity:
#     entities = Entity.objects()
    
#     return entities

# def get_entity_by_id(id) -> Entity:
#     entity = Entity.objects(id=id).first()

#     return entity
