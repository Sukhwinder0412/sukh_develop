import bson
from db.data.configs import Config


def get_all_configs() -> Config:
    configs = Config.objects()
    
    return configs


def add_config(language:str, content:str) -> Config:
    prev_config = Config.objects(name=language).first()
    if prev_config:
        prev_config.name = language
        prev_config.content = content
        prev_config.save()
        with open (f"./config_{language}.yml", "w") as f:
            f.write(str(content).replace("↵", "\n"))
        return prev_config
    config = Config()
    config.name = language
    config.content = content
    with open (f"./config_{language}.yml", "w") as f:
        f.write(str(content).replace("↵", "\n"))

    config.save()
    return config
# def find_entity_by_language(language: str) -> Entity:
#     entity = Entity.objects(language=language).first()
#     return entity


# def delete_action(id: str) -> Action:
#     action = Action.objects(id=id).all()
#     action.delete()
#     return f"Deleted!"


# def update_entity(id:str, language:str) -> Entity:
#     entity = Entity.objects(id=id).first()
#     entity.language = language

#     entity.save()
#     return entity



# def get_entity_by_id(id) -> Entity:
#     entity = Entity.objects(id=id).first()

#     return entity
# import bson
# from db.data.entities import Entity


# def add_entity(language:str) -> Entity:
#     prev_entity = Entity.objects(language=language).all()
#     if prev_entity:
#         return {"success":True}
#     entity = Entity()
#     entity.language = language

#     entity.save()
#     return {"success":True}


# def find_entity_by_language(language: str) -> Entity:
#     entity = Entity.objects(language=language).first()
#     return entity


# def delete_entity(id: str) -> Entity:
#     entity = Entity.objects(id=id).all()
#     entity.delete()
#     return f"Deleted!"


# def update_entity(id:str, language:str) -> Entity:
#     entity = Entity.objects(id=id).first()
#     entity.language = language

#     entity.save()
#     return entity


# def get_all_entities() -> Entity:
#     entities = Entity.objects()
    
#     return entities

# def get_entity_by_id(id) -> Entity:
#     entity = Entity.objects(id=id).first()

#     return entity
