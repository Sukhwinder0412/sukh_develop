import re
from bson.json_util import dumps
import bson
from db.data.conversations import Conversation
import pymongo
import datetime
from db.data.mongo_setup import global_init

# from .story_service import delete_story_by_name

# latest_input_channel=None, active_form = None latest_event_time = None followup_action = None sender_id = None paused = None latest_message = None slots = None events = None latest_action_name = None


def get_all_conversations() -> Conversation:

    pipeline = [{"$project": {"_id": 0, "sender_id": 1, "latest_event_time": 1}}]
    convs = Conversation.objects().aggregate(pipeline)

    # print(convs)
    # print(type(convs))
    # conversation = Conversation.objects().all() # choosing the collection you need

    return list(convs)


def get_conversation_by_id(sender_id) -> Conversation:

    convs = Conversation.objects(sender_id=sender_id).first()

    return convs


def get_conversation(sender_id=None, t1=None, t2=None) -> Conversation:

    pipeline = []
    f = r"^" + str(sender_id)
    # print(t1)
    senderId_pipeline = [{"$match": {"sender_id": {"$regex": re.compile(f)}}}]
    try:
        time_pipeline = [
            {"$match": {"latest_event_time": {"$gte": float(t1)}}},
            {"$match": {"latest_event_time": {"$lte": float(t2)}}},
        ]
    except:
        pass
    if sender_id:
        for x in senderId_pipeline:
            pipeline.append(x)
        # pipeline.append(x) for x in senderId_pipeline
    if t1 is not None and t2 is not None:
        for x in time_pipeline:
            # print(x)
            pipeline.append(x)
        # pipeline.append(c) for c in time_pipeline
    #     pipeline = [
    #     {
    #         '$match': {
    #             'latest_event_time': {
    #                 '$gte': 1615104500
    #             }
    #         }
    #     }, {
    #         '$match': {
    #             'latest_event_time': {
    #                 '$lte': 1615106496
    #             }
    #         }
    #     }
    # ]
    if sender_id is not None:
        # print(pipeline)
        convs = Conversation.objects().aggregate(pipeline)
        # print(convs)
    else:
        convs = Conversation.objects().aggregate(pipeline)
    result = list(convs)
    # print(result)
    json_data = dumps(result, indent=2)
    # print(convs.to_json())
    # print(list(convs))
    # conversation = Conversation.objects().all() # choosing the collection you need

    return json_data


def get_all_utterances() -> Conversation:

    pipeline = [
        {"$project": {"events": 1}},
        {"$unwind": {"path": "$events"}},
        {"$match": {"events.event": "user"}},
        {
            "$project": {
                "_id": 0,
                "events.parse_data.text": 1,
                "events.parse_data.intent": 1,
            }
        },
    ]
    convs = Conversation.objects().aggregate(pipeline)

    # print(convs)
    # print(type(convs))
    # conversation = Conversation.objects().all() # choosing the collection you need

    return list(convs)


def getCount():

    convs = Conversation.objects().count()
    return convs
