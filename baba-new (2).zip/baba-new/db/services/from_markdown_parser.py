import yaml

with open('domain1.yml') as f:
    
    docs = yaml.load_all(f, Loader=yaml.FullLoader)
    test_dict = {}
    for doc in docs:

        for k, v in doc.items():
            # #print(k, "->", v)   
            test_dict[k] = v

    # #print(test_dict)
#print(type(test_dict["responses"]["utter_greetings"]))
for x in test_dict["responses"].keys():
    resp = {}
    # #print(x)
    resp["name"] = x
    text_list = []
    text_dict = {}
    buttons_list = []
    for y in test_dict["responses"][x]:
        if "text" in y.keys():
            text_dict["data"] = y["text"]
            text_list.append({"data":y["text"], "canonical": False})
        
            if "buttons" in y.keys():
                # #print(y["buttons"])
                for z in y["buttons"]:
                    buttons_list.append({"title":z["title"],"payload":z["payload"]})
                # #print("buttons_list",buttons_list)
                    

        # #print(y.keys())
        resp["text"] = text_list
        if len(buttons_list) > 1:
            resp["buttons"] = buttons_list
        #print(resp)
        # #print(y["text"])
    # #print(test_dict["responses"][x])