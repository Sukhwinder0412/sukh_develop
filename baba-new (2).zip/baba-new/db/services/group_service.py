import bson
from db.data.groups import Group
from .story_service import delete_story_by_name


def create_group(name: str, stories: list = [], status: bool = True, partial_training: bool = False) -> Group:
    old_group = Group.objects(name=name).first()
    if old_group:
        return f"ERROR: Group with name {name} already exists"
    group = Group()
    group.name = name
    group.stories = stories
    group.status = status
    group.partial_training = partial_training
    group.save()

    return group


def find_group_by_name(name: str) -> Group:
    group = Group.objects(name=name).first()

    return group


def delete_group(id: str) -> Group:
    group = Group.objects(id=id).first()
    stories= group.stories
    for x in stories:
        z = delete_story_by_name(x)
    group.delete()

    return group


def update_group(id: str, name: str, stories: list = [], status: bool = True, partial_training: bool = False) -> Group:
    group = Group.objects(id=id).first()
    old_group = Group.objects(name=name).first()
    try:
        if old_group.id != group.id:
            return f"ERROR: Group with name {name} already exists"
    except Exception as e:
        print(e)
        pass
    group.name = name
    group.stories = stories
    group.status = status
    group.partial_training = partial_training

    group.save()
    return group


def get_all_groups() -> Group:
    groups = Group.objects()
    pipeline = [
    {
        '$lookup': {
            'from': 'responses', 
            'localField': 'responses', 
            'foreignField': 'name', 
            'as': 'responses_objects'
        }
    }, {
        '$lookup': {
            'from': 'intents', 
            'localField': 'intents', 
            'foreignField': 'name', 
            'as': 'intents_objects'
        }
    }
    ]
    return groups


def get_group_by_id(id) -> Group:
    group = Group.objects(id=id).first()

    return group

def getCount():

    count = Group.objects().count()
    return count