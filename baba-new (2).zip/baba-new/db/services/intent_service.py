import bson
import re
from db.data.intents import Intent
import db.data.mongo_setup as mongo_setup
import json
from bson.json_util import dumps
from .entity_service import add_entity

def create_intent(name: str, text: list = None, in_stories: list = None, entities:list = []) -> Intent:
    old_intent = Intent.objects(name=name).first()
    if old_intent:
        return f"ERROR! Intent with name {name} already exists"
    intent = Intent()
    intent.name = name
    intent.text = text
    for t in text:
        try:
            if len(t["entities"]) > 0:
                for entity in t["entities"]:
                    result = add_entity(entity["name"])
                    if result["success"] == False:
                        return json.dumps({"success": False})
        except Exception as e:
            print(e)
            pass
    intent.in_stories = in_stories

    intent.save()
    return intent

def find_intent_by_name(name: str) -> Intent:
    intent = Intent.objects(name=name).first()

    return intent

def intent_search(name: str, skip, limit) -> Intent:
    pipeline = [
        {
            "$skip":skip
        },
        {
            "$limit":limit
        }
    ]
    # pipeline.append({'$skip':skip}) if skip is not None else print("0")
    # pipeline.append({'$limit':limit}) if limit is not None else print("0")
    regex = re.compile(f'.*{name}.*')
    intent = Intent.objects(name=regex).all().aggregate(pipeline)
    # intent = list(intent)
    # print("KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK")
    result = list(intent)
    intent = dumps(result, indent = 2) 
    # intent = json.loads(intent)
    return intent

def delete_intent(id: str, ) -> Intent:
    pipeline = [
    {
        '$lookup': {
            'from': 'stories', 
            'localField': 'name', 
            'foreignField': 'intents', 
            'as': 'in_story'
        }
    }
    ]
    intent = Intent.objects(id = id).all().aggregate(pipeline)
    result = list(intent)
    intent = dumps(result, indent = 2) 
    intent = json.loads(intent)

    if len(intent[0]["in_story"]) > 0:
        return {"success": False, "message": "Responses that are in stories cannot be deleted"}
    intent = Intent.objects(id = id).all()
    intent.delete()
    return {"success": True, "data": "Response deleted"}

def update_intent(id: str, name: str, text: list = None, in_stories: list = None, slots: list = None, entities:list = []) -> Intent:
    # text1 = []
    intent = Intent.objects(id=id).first()
    old_intent = Intent.objects(name=name).first()
    try:
        # print(old_intent[0])
        if old_intent.id != intent.id:

            return f"ERROR: Intent with name {name} already exists"
    except Exception as e:
        print(e)
        pass
    intent.name = name
    for t in text:
        try:
            if len(t["entities"]) > 0:
                for entity in t["entities"]:
                    result = add_entity(entity["name"])
                    if result["success"] == False:
                        return json.dumps({"success": False})
        except Exception as e:
            pass
    intent.text = text
    intent.in_stories = in_stories

    intent.save()
    return intent

def set_canonical(id: str, text: list) -> Intent:
    # pipeline = [
    #     {
    #         '$match':
    #             {"id":id,"text.language": text[0]["language"]}
    #     }
    # ]
    intent = Intent.objects(id=id).first()
    # intent.text.update()
    # print(list(intent))
    prev_text = intent.text
    # print(prev_text)
    for x in prev_text:
        # x["canonical"]=False
        if x["data"] == text[0]["data"]:
            x["canonical"] = True

    intent.save()
    return intent

def del_canonical(id: str) -> Intent:
    # pipeline = [
    #     {
    #         '$match':
    #             {"text.language": language}
    #     }
    # ]
    intent = Intent.objects(id=id).first()
    # intent.text.update()
    prev_text = intent.text
    for x in prev_text:
        x["canonical"]=False

    intent.save()
    return intent


def intent_names() -> Intent:
    # pipeline = [
    # {
    #     '$project': {
    #         'name': 1
    #     }
    # }
    # ]
    pipeline = []
    intents = Intent.objects().all().aggregate(pipeline)
    # print(type(intents))
    # k = []
    # k.append(inten.to_json for inten in intents)
    # print(k)
    k = list(intents)
    json_data = dumps(k, indent=2)

    return json_data


def get_all_intents(language: str, skip: int=0, limit: int=200) -> Intent:
    pipeline = [
    {
        '$match': {
            'text': {
                '$elemMatch': {
                    'language': language
                }
            }
        }
    }, {
        '$project': {
            'text': {
                '$filter': {
                    'input': '$text', 
                    'as': 'item', 
                    'cond': {
                        '$eq': [
                            '$$item.language', language
                        ]
                    }
                }
            }, 
            'name': 1, 
            'in_stories': 1, 
            'synonyms': 1, 
            'entities': 1
        }
    }
]
    pipeline.append({'$skip':skip}) if skip is not None else print("")
    pipeline.append({'$limit':limit}) if limit is not None else print("")
    intents = Intent.objects().aggregate(pipeline)
    result = list(intents)
    json_data = dumps(result, indent=2)

    return json_data


def get_all_intents_internal() -> Intent:
    intents = Intent.objects()

    return intents

def get_intent_by_id(id) -> Intent:
    intent = Intent.objects(id=id).first()

    return intent

def getCount():

    count = Intent.objects().count()
    return count

def nlg_intents(name: str, text: list = None, in_stories: list = None, slots: list = None, entities:list = []) -> Intent:
    # text1 = []
    # intent = Intent.objects(id=id).first()
    old_intent = Intent.objects(name=name).first()
        # print(old_intent[0])
    for t in text:
        try:
            if len(t["entities"]) > 0:
                for entity in t["entities"]:
                    result = add_entity(entity["name"])
                    if result["success"] == False:
                        return json.dumps({"success": False})
        except Exception as e:
            print(e)
            pass
    if old_intent:
        old_texts = old_intent.text
        old_intent.text = old_texts + text
        old_intent.save()
        return old_intent
    else:
        intent = Intent()
        intent.name = name
        intent.text = text
        intent.in_stories = in_stories

        intent.save()
        return intent