from re import S
import bson
from db.data.languages import Language
import db.services.project_config_service as pconfig_svc
import json
from bson.json_util import dumps


def add_language(name: str, code: str, port: int, channel: str) -> Language:
    old_intent = Language.objects(name=name).first()
    if old_intent:
        return f"ERROR! Language with name {name} already exists"
    language = Language()
    language.name = name
    language.code = code
    language.port = port
    conf = pconfig_svc.get_all_configs()
    conf = json.loads(conf.to_json())
    print(conf)
    conf[0]["content"]["channels"][str(channel)][name] = port
    _ = pconfig_svc.add_config(conf[0]["name"], conf[0]["content"])
    language.save()
    return language


def get_all_languages() -> Language:
    languages = Language.objects()

    return languages


def delete_language(name) -> Language:
    language = Language.objects(name=name).first()
    language.delete()

    return "Language deleted"


def getCount():

    count = Language.objects().count()
    return count