import bson
from db.data.project_config import Config


def get_all_configs() -> Config:
    configs = Config.objects()

    return configs


def add_config(name: str, content: dict) -> Config:
    prev_config = Config.objects(name=name).first()
    if prev_config:
        prev_config.name = name
        prev_config.content = content
        prev_config.save()
        return prev_config
    config = Config()
    config.name = name
    config.content = content
    # with open(f"./config_{name}.yml", "w") as f:
    #     f.write(str(content).replace("↵", "\n"))

    config.save()
    return config


# k = add_config("port_mappings", {"channels": {"Whatsapp": {"en": 3001}}})
