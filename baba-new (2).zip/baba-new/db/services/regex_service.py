import bson
from db.data.regex import Regex


def get_all_regex() -> Regex:
    actions = Regex.objects()

    return actions


def add_regex(name: str, text: str) -> Regex:
    prev_action = Regex.objects(name=name).all()
    if prev_action:
        return "Error! Action already exists!"
    regex = Regex()
    regex.name = name
    regex.text = text

    regex.save()
    return regex


def update_regex(id: str, name: str, text: str) -> Regex:
    regex = Regex.objects(id=id).first()
    regex.name = name
    regex.text = text

    regex.save()
    return regex


# def find_entity_by_name(name: str) -> Entity:
#     entity = Entity.objects(name=name).first()
#     return entity


def delete_regex(id: str) -> Regex:
    regex = Regex.objects(id=id).all()
    regex.delete()
    return f"Deleted!"