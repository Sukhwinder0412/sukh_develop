import re
import bson
from db.data.responses import Response
from bson.json_util import dumps
import json


def create_response(name: str, text: list = None, in_stories: list = None, buttons: list = None, responseype: str = None) -> Response:
    old_response = Response.objects(name=name).first()
    if old_response:
        return f"Response with name {name} already exists"
    response = Response()
    response.name = name
    response.text = text
    response.in_stories = in_stories
    response.responsetype = responseype
    # response.buttons = buttons
    # response.images = images
    response.save()

    return response


def find_response_by_name(name: str) -> Response:
    response = Response.objects(name=name).first()
    return response

def response_search(name: str, skip, limit) -> Response:
    pipeline = [
        {
            "$skip":skip
        },
        {
            "$limit":limit
        }
    ]
    # pipeline.append({'$skip':skip}) if skip is not None else print("0")
    # pipeline.append({'$limit':limit}) if limit is not None else print("0")
    regex = re.compile(f'.*{name}.*')
    response = Response.objects(name=regex).all().aggregate(pipeline)
    # print("KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK")
    result = list(response)
    response = dumps(result, indent = 2) 
    return response


def delete_response(id: str) -> Response:
    pipeline = [
        {
            '$lookup': {
                'from': 'stories',
                'localField': 'name',
                'foreignField': 'responses',
                'as': 'in_story'
            }
        }
    ]
    response = Response.objects(id=id).all().aggregate(pipeline)
    result = list(response)
    response = dumps(result, indent=2)
    response = json.loads(response)
    if len(response[0]["in_story"]) > 0:
        return {"success": False, "message": "Responses that are in stories cannot be deleted"}
    response = Response.objects(id=id).all()
    response.delete()
    return {"success": True, "data": "Response deleted"}


def update_response(id: str, name: str, text: list = None, in_stories: list = None, buttons: list = None, responseype: str = None) -> Response:
    # text1 = []
    # images1 = []
    response = Response.objects(id=id).first()
    old_response = Response.objects(name=name).first()
    try:
        # print(old_response[0])
        if old_response.id != response.id:

            return f"ERROR: Response with name {name} already exists"
    except Exception as e:
        print(e)
        pass
    response.name = name
    # response = Response()
    # prev_text = response.text
    # for x in text:
    #     text2 = []
    #     print("test")
    #     for y in prev_text:
    #         print(x["data"])
    #         print(y["data"])
    #         if x["data"] == y["data"]:
    #             print("ok")
    #             text2 = []
    #             break
    #         else:
    #             text2.append(x)
    #             print(text2)
    #             pass
    #     # continue
    #     print(text2)
    #     # text2.append(x)
    # text2 = list({v['data']:v for v in text2}.values())
    # print(text2)
    # response.text = text2 + prev_text
    response.text = text
    # prev_images = response.images
    # for x in images:
    #     if x in prev_images:
    #         continue
    #     else:
    #         images1.append(x)
    # print(images1)
    # response.images = images1 + prev_images
    # response.images = images
    # response.text = text1 + prev_text
    response.in_stories = in_stories
    response.responsetype = responseype
    # response.buttons = buttons

    response.save()
    return response


def set_canonical(id: str, text: list) -> Response:
    # pipeline = [
    #     {
    #         '$match':
    #             {"text.language": language}
    #     }
    # ]
    response = Response.objects(id=id).first()
    # response.text.update()
    prev_text = response.text
    for x in prev_text:
        # x["canonical"] = False
        if x["data"] == text[0]["data"]:
            x["canonical"] = True

    response.save()
    return response


def del_canonical(id: str) -> Response:
    # pipeline = [
    #     {
    #         '$match':
    #             {"text.language": language}
    #     }
    # ]
    response = Response.objects(id=id).first()
    # response.text.update()
    prev_text = response.text
    for x in prev_text:
        x["canonical"] = False

    response.save()
    return response


def response_names() -> Response:
    pipeline = [
    {
        '$project': {
            'name': 1
        }
    }
    ]
    responses = Response.objects().aggregate(pipeline)
    result = list(responses)
    json_data = dumps(result, indent=2)

    return json_data


def get_all_responses(language: str, skip: int=0, limit: int=20) -> Response:
    pipeline = [{
        '$match': {
            'text': {
                '$elemMatch': {
                    'language': language
                }
            }
        }
    }, {
        '$project': {
            'text': {
                '$filter': {
                    'input': '$text', 
                    'as': 'item', 
                    'cond': {
                        '$eq': [
                            '$$item.language', language
                        ]
                    }
                }
            }, 
            'name': 1, 
            'in_stories': 1, 
            'synonyms': 1, 
            'entities': 1
        }
    }
]
    pipeline.append({'$skip':skip}) if skip is not None else print("0")
    pipeline.append({'$limit':limit}) if limit is not None else print("0")
    # if skip is None:
    responses = Response.objects().aggregate(pipeline)
    result = list(responses)
    json_data = dumps(result, indent=2)

    return json_data


def get_all_responses_internal() -> Response:
    responses = Response.objects()

    return responses

def get_response_by_id(id) -> Response:
    response = Response.objects(id=id).first()

    return response

def getCount():

    count = Response.objects().count()
    return count

# def del_text(id:str, text:list) -> Response:
#     response = Response.objects(id=id).first()
#     prev_text = response.text
#     text2 = []
#     for y in prev_text:
#         if text[0]["data"] == y["data"]:
#             continue
#         else:
#             text2.append(y)
#     # print(text2)
#     response.text = text2

#     response.save()
#     return response
