import bson
from db.data.slots import Slot
import json
# Slot()

def create_slot(contents) -> Slot:
    name = contents["name"]
    prev_slot = Slot.objects(name=name).first()
    if prev_slot:
        return f"Error! Slot with {name} already exists!"
    slot = Slot()
    slot.name = name
    slot.typename = contents["typename"]
    try:
        slot.initial_value = contents["initial_value"]
    except:
        slot.initial_value = ""
        pass
    try:
        slot.categories = contents["categories"]
    except:
        slot.categories = []
        pass
    try:
        slot.min_value = contents["min_value"]
    except:
        slot.min_value = ""
        pass
    try:
        slot.max_value = contents["max_value"]
    except:
        slot.max_value = ""
        pass

    slot.save()
    return slot


def find_slot_by_name(name: str) -> Slot:
    slot = Slot.objects(name=name).first()

    return slot


def delete_slot(id: str) -> Slot:
    slot = Slot.objects(id=id).all()

    slot.delete()
    return {"success":True, "message":"slot deleted"}


def get_all_slots() -> Slot:
    slots = Slot.objects()

    return slots


def get_slot_by_id(id) -> Slot:
    slot = Slot.objects(id=id).first()

    return slot

def getCount():

    count = Slot.objects().count()
    return count