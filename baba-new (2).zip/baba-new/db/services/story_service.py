import bson
from db.data.stories import Story
import mongoengine
import json
import bson
from bson.json_util import dumps

def handling_intents_rsponses(content):
    intents_list = []
    responses_list = []
    # for x in content:
    # print(content)
    if len(content["story"]) != 0:
        for y in content["story"]:
            if y["type"] == "intent":
                intents_list.append(y["data"])
            elif y["type"] == "response":
                responses_list.append(y["data"])
        if len(content["branches"]) != 0:
            for z in content["branches"]:
                i_list, r_list = handling_intents_rsponses(z)
                intents_list = intents_list + i_list
                responses_list = responses_list + r_list
    return(list(set(intents_list)), list(set(responses_list)))
def create_story(name: str, group: str, content: dict = None, actions: list = None, slots: list = None) -> Story:
    old_story = Story.objects(name=name).first()
    if old_story:
        return f"ERROR: Story with name {name} already exists"
    story = Story()
    story.name = name
    story.group = group
    story.content = content
    intents, responses = handling_intents_rsponses(content)
    story.intents = intents
    story.responses = responses
    story.actions = actions
    story.slots = slots
    
    story.save()

    return story


def get_story_by_name_(name: str) -> Story:
    pipeline = [
    {
        '$lookup': {
            'from': 'responses', 
            'localField': 'responses', 
            'foreignField': 'name', 
            'as': 'response_object'
        }
    }, {
        '$lookup': {
            'from': 'intents', 
            'localField': 'intents', 
            'foreignField': 'name', 
            'as': 'intent_object'
        }
    }
    ]
    stories = Story.objects(name=name).aggregate(pipeline)
    # stories = stories.aggregate(pipeline)
    # cursor = mongoengine.QuerySet.aggregate(Story,pipeline=pipeline)
    # print(stories)
    result = list(stories)
    json_data = dumps(result, indent = 2)  
    # print(json_data)
    # result = list(json.loads(stories.to_json()))
    return json_data


def delete_story(id: str) -> Story:
    story = Story.objects(id=id).all()
    story.delete()

    return json.dumps({"success":True, "data": "Story deleted"})

def delete_story_by_name(name: str) -> Story:
    story = Story.objects(name=name).all()
    story.delete()

    return json.dumps({"success":True, "data": "Story deleted"})

def update_story(id: str, name: str, group: str, content: dict = None, actions: list = None, slots: list = None) -> Story:
    story = Story.objects(id=id).first()
    old_story = Story.objects(name=name).first()
    try:
        # print(old_story[0])
        if old_story.id != story.id:
            return f"ERROR: Story with name {name} already exists"
    except Exception as e:
        print(e)
        pass
    story.name = name
    story.group = group
    story.content = content
    intents, responses = handling_intents_rsponses(content)
    story.intents = intents
    story.responses = responses
    story.actions = actions
    story.slots = slots

    story.save()
    return story


def get_all_stories() -> Story:
    pipeline = [
    {
        '$lookup': {
            'from': 'responses', 
            'localField': 'responses', 
            'foreignField': 'name', 
            'as': 'responses_objects'
        }
    }, {
        '$lookup': {
            'from': 'intents', 
            'localField': 'intents', 
            'foreignField': 'name', 
            'as': 'intents_objects'
        }
    }
    ]
    stories = Story.objects().aggregate(pipeline)
    # cursor = mongoengine.QuerySet.aggregate(Story,pipeline=pipeline)
    # print(stories)
    result = list(stories)
    json_data = dumps(result, indent = 2)  
    # print(json_data)
    # result = list(json.loads(stories.to_json()))
    return json_data


def get_story_by_name(name, language) -> Story:
    # pipeline = [
    # {
    #     '$lookup': {
    #         'from': 'responses', 
    #         'localField': 'responses', 
    #         'foreignField': 'name', 
    #         'as': 'response_object'
    #     }
    # }, {
    #     '$lookup': {
    #         'from': 'intents', 
    #         'localField': 'intents', 
    #         'foreignField': 'name', 
    #         'as': 'intent_object'
    #     }
    # }
    # ]
    pipeline = [
    {
        '$lookup': {
            'from': 'responses', 
            'let': {
                'responseObject': '$responses'
            }, 
            'pipeline': [
                {
                    '$match': {
                        '$expr': {
                            '$in': [
                                '$name', {
                                    '$ifNull': [
                                        '$$responseObject', []
                                    ]
                                }
                            ]
                        }
                    }
                }, {
                    '$project': {
                        'text': {
                            '$filter': {
                                'input': '$text', 
                                'as': 'item', 
                                'cond': {
                                    '$eq': [
                                        '$$item.language', language
                                    ]
                                }
                            }
                        }, 
                        'name': 1, 
                        'in_stories': 1, 
                        'synonyms': 1, 
                        'entities': 1
                    }
                }
            ], 
            'as': 'response_object'
        }
    }, {
        '$lookup': {
            'from': 'intents', 
            'let': {
                'intentObject': '$intents'
            }, 
            'pipeline': [
                {
                    '$match': {
                        '$expr': {
                            '$in': [
                                '$name', {
                                    '$ifNull': [
                                        '$$intentObject', []
                                    ]
                                }
                            ]
                        }
                    }
                }, {
                    '$project': {
                        'text': {
                            '$filter': {
                                'input': '$text', 
                                'as': 'item', 
                                'cond': {
                                    '$eq': [
                                        '$$item.language', language
                                    ]
                                }
                            }
                        }, 
                        'name': 1, 
                        'in_stories': 1, 
                        'synonyms': 1, 
                        'entities': 1
                    }
                }
            ], 
            'as': 'intent_object'
        }
    }
    ]
    stories = Story.objects(name=name).aggregate(pipeline)
    # stories = stories.aggregate(pipeline)
    # cursor = mongoengine.QuerySet.aggregate(Story,pipeline=pipeline)
    result = list(stories)
    json_data = dumps(result, indent = 2)  
    # print(json_data)
    # result = list(json.loads(stories.to_json()))
    return json_data

def getCount():

    count = Story.objects().count()
    return count