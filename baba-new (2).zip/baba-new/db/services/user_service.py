import bson
from db.data.users import User


def get_user(username: str, password: str) -> User:
    user = User.objects(username=username).first()
    return user


def add_user(username: str, password: str,email: str,role: str) -> User:
    prev_user = User.objects(username=username).all()

    if prev_user:
        return "user already exists"
    user = User()
    user.username = username
    user.password = password
    user.email    = email
    user.role     = role

    user.save()
    return user