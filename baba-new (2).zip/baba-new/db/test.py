import json
result = {'year': '2018',
          'month': '12'}
file_name="Check"
with open('{}.md'.format(file_name), mode='w') as md_file:
    md_file.write(str(result))