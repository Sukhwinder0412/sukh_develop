import db.services.story_service as story_svc
import db.services.response_service as response_svc
import db.services.intent_service as intent_svc
import db.services.group_service as group_svc
import db.services.entity_service as entity_svc
import db.services.slots_service as slot_svc
import db.services.action_service as action_svc
import db.services.regex_service as regex_svc
import yaml
import json
import db.data.mongo_setup as mongo_setup

text = 1
check_list_of_story = []
# intents = intent_svc.get_all_intents()
# entities = entity_svc.get_all_entities()
# responses = response_svc.get_all_responses()
# stories = story_svc.get_all_stories()
# groups = group_svc.get_all_groups()
def initialize():
    intents = intent_svc.get_all_intents_internal()
    entities = entity_svc.get_all_entities()
    responses = response_svc.get_all_responses_internal()
    stories = story_svc.get_all_stories()
    groups = group_svc.get_all_groups()
    slots = slot_svc.get_all_slots()
    actions = action_svc.get_all_actions()
    # regex = regex_svc.get_all_regex()
    return intents, entities, responses, stories, groups, slots, actions  # , regex


# #print(groups)

# def test_read():
#     with open(r"domain1.yml") as f:
#         # #print(f)
#         data = yaml.load(f, Loader=yaml.FullLoader)
#         # #print(data)


def test_write_domain(language):
    intents, entities, responses, stories, groups, slots, actions = initialize()
    # #print(responses)
    intent_names = []
    response_names = []
    entity_names = []
    slots_names = []
    action_names = []
    form_names = []
    slot_names_with_text = {}
    # if len(entities) > 1:
    for entity in entities:
        entity_names.append(entity.name)

    for intent in intents:
        intent_names.append(intent.name)
        # #print(intent)

    for response in responses:
        response_names.append(response.name)
        # #print(response)

    for action in actions:
        # print("JJ")
        action_names.append(action.name) if action.name.startswith(
            "action"
        ) else form_names.append(action.name)
        # jk = input("Waitt")
        # print("KK")
    for slot in slots:
        slots_names.append(slot.name)
        test_dict_slots = {}
        if len(slot.typename) > 0:
            test_dict_slots["type"] = slot.typename
        try:
            try:
                if len(slot.initial_value) > 0:
                    test_dict_slots["initial_value"] = float(slot.initial_value)
            except:
                if len(slot.initial_value) > 0:
                    test_dict_slots["initial_value"] = slot.initial_value
        except:
            pass
        try:
            if len(slot.categories) > 0:
                test_dict_slots["values"] = [category for category in slot.categories]
        except:
            pass
        try:
            try:
                if len(slot.min_value) > 0:
                    test_dict_slots["min_value"] = float(slot.min_value)
                if len(slot.max_value) > 0:
                    test_dict_slots["max_value"] = float(slot.max_value)
            except:
                if len(slot.min_value) > 0:
                    test_dict_slots["min_value"] = slot.min_value
                if len(slot.max_value) > 0:
                    test_dict_slots["max_value"] = slot.max_value
        except:
            pass
        slot_names_with_text[slot.name] = [test_dict_slots]

    response_with_text = {}
    for response in responses:
        response_text_list = []
        response_buttons = {}
        buttons_list = []
        response_images = {}
        image_list = []
        for x in response.text:
            try:
                # print(x)
                # print(x["language"])
                # print(language)
                # jk = input("test-wait")

                if x["language"] != str(language[0]):
                    print("THIS IS OKAY")
                    # print(x["language"])
                    # print(str(language))
                    continue
            except Exception as e:
                print(e)
                print("LOOOK AT THIS!")
                continue
            response_text = {}
            # #print(text["data"])
            # for x in response.text:
            # print(x)
            try:
                for button in x["buttons"]:
                    response_buttons = {}
                    response_buttons["title"] = button["title"]
                    response_buttons["type"] = "postback"
                    response_buttons["payload"] = r"/" + button["payload"]
                    # #print(response_buttons)
                    buttons_list.append(response_buttons)
                    # for x in sorted(response_buttons.keys(), reverse=True):
                    #     buttons_list.append([{x: response_buttons[x]}])
            except Exception as e:
                print(e)
                pass
            if "images" in x.keys():
                for image in x["images"]:
                    if image:
                        # #print(image)
                        # #print(image)
                        response_images["image"] = image
                        image_list.append(image)

                    # response_images.append({"image": image})
            # if len(image_list) >= 1:``
            #     for x in image_list:
            #         response_text_list.append({"image": x})
            response_text["text"] = x["data"]
            # print(x)
            # #print(buttons_list)
            if len(buttons_list) > 1:
                response_text["buttons"] = buttons_list
                buttons_list = []
            # #print(image_list)
            if len(image_list) > 1:
                response_text["image"] = image_list[0]
                image_list = []
            try:
                response_text["language"] = x["language"]
            except:
                response_text["language"] = "en"

            # except:
            #     pass
            response_text_list.append(response_text)

        # #print(buttons_list)
        # if len(buttons_list) >= 1:
        #     response_text_list.append({"buttons": buttons_list})
        # #print("RESP_TEXT_LIST", response_text_list)
        response_with_text[response.name] = response_text_list

    # #print(response_with_text)
    # if len(entity_names) > 1:
    #     final_dict = {
    #         "intents": [intent_names],
    #         "actions": [action_names],
    #         "entities": [entity_names],
    #         "forms": [form_names],
    #         "slots": slot_names_with_text,
    #         "responses": response_with_text,
    #     }
    # else:
    final_dict = {
        "intents": [intent_names],
        "actions": [action_names],
        "forms": [form_names],
        "slots": slot_names_with_text,
        "responses": response_with_text,
    }

    with open(r"domain1.yml", "w") as file:
        documents = yaml.dump(final_dict, file, sort_keys=False)


def test_write_nlu(language):
    # intents, entities, responses, stories, groups, slots = initialize()
    # print("language", language)
    intents = intent_svc.get_all_intents(language)
    regex = regex_svc.get_all_regex()
    intents = json.loads(intents)
    md_file = open(f"nlu_{language}.md", "w")
    # #print(responses)
    final_string = r""""""
    final_string += f"#lang: {language}\n"
    intent_list = []
    # print(type(intents))
    for intent in intents:
        # print(intent["name"])
        # #print(intent.text)
        # #print("\n")-
        intent_name = "\n\n## intent:{}\n".format(intent["name"])
        final_string += intent_name
        # intent_list = list(set(x["data"]) for x in intent.text)
        try:
            intent_list = []
            for x in intent["text"]:
                # print(x)
                if "entities" in x.keys():
                    # #print("GG",x)
                    for y in range(len(x["entities"])):
                        # #print(x["entities"][y])
                        j = x["entities"][y]["value"]
                        n = x["entities"][y]["name"]
                        data = x["data"].replace(j, f"[{j}]({n})")
                        # #print(data)
                        intent_list.append(data)
                else:
                    data = x["data"]
                    intent_list.append(data)
        except Exception as e:
            # print("HHHH")
            # print(e)
            pass
        intent_list = list(set(intent_list))
        # #print("intent_list")
        # #print(intent_list)
        length = len(intent_list)
        i = 1
        for x in intent_list:
            # #print(i)
            if i == length:
                # #print("oh")
                final_string += f"- {x}"
            else:
                final_string += f"- {x}\n"
            i += 1
    # md_file.write(final_string)

    for r in regex:
        # print(intent["name"])
        # #print(intent.text)
        # #print("\n")-
        try:
            regex_name = "\n\n## regex:{}\n".format(r["name"])
            final_string += regex_name
            # intent_list = list(set(x["data"]) for x in intent.text)
            regex_list = []
            regex_list.append(r["text"])
            regex_list = list(set(regex_list))
            length = len(regex_list)
            i = 1
            for x in regex_list:
                # #print(i)
                final_string += f"- {x}\n"
        except Exception as e:
            print("Writing Regex error", e)

    md_file.write(final_string)


def test_first_branch(branches, final_string, md_file, story_name):
    global test
    global check_list_of_story
    for x in branches:
        # try:
        #     #print(x)
        # except:
        #     pass
        story = x["story"]
        branch_name = x["branch_name"]
        writing_to_md(
            story, final_string, md_file, branch_name=branch_name, story_name=story_name
        )
        try:
            branches = x["branches"]
            # #print("LLLLLLLLLLLLLLLLLLLLL", branches)
            test = 1
            # #print(len(branches))
            test_first_branch(
                branches,
                final_string,
                md_file,
                story_name=story_name + "__" + x["branch_name"],
            )
        except:
            check_list_of_story = []
            return


def writing_to_md(content_list, final_string, md_file, branch_name="", story_name=""):
    global test
    # #print("STORY_NAME", branch_name)
    # print("HH\n"*10)
    # print(story_name)
    # try:
    #     print(test)
    # except Exception as e:
    #     print(e)
    #     pass
    # print(check_list_of_story)
    # lpo = input("press to continue")
    try:
        if len(story_name) > 0:
            try:
                if test == 1:
                    if story_name not in check_list_of_story:
                        final_string += f"> {story_name}" + "__" + "branches\n"
                        check_list_of_story.append(story_name)
                    test = 0
            except:
                # print("OOOOOOHHHH")
                pass
            final_string += f"## {story_name}__{branch_name}\n"
            final_string += f"> {story_name}" + "__" + "branches\n"
    except:
        pass
    length = len(content_list)
    i = 1
    # print("MMM", content_list)
    for x in content_list:
        # print("KKK", x.keys())
        if i == length:
            if x["type"] == "response":
                final_string += "  - {}\n\n".format(x["data"])
            elif x["type"] == "intent":
                # print("LLL",x["data"])

                # if "entities" in x.keys():
                #     # print("PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP")
                #     to_add = {}
                #     # print(x["entities"])
                #     if len(x["entities"]) > 0:
                #         for y in x["entities"]:
                #             # print("LL", y)
                #             e_name = y["name"]
                #             e_value = y["value"]
                #             to_add[e_name] = e_value
                #         # to_add = '{"' + y["name"] +
                #     # to_write = "* {}{\n\n".format(x["data"]
                #     # print("* {}".format(x["data"]) + str(to_add) + "\n\n")
                #     # lpo = input("waiter")
                #     if len(to_add.keys()) > 0:
                #         final_string += "* {} ".format(x["data"]) + str(to_add) + "\n\n"
                #     else:
                #         final_string += "* {}".format(x["data"]) + "\n\n"
                # else:
                final_string += "* {}\n\n".format(x["data"])
            elif x["type"] == "action":
                final_string += "  - {}\n\n".format(x["data"])
            elif x["type"] == "form":
                final_string += "  - {}\n\n".format(x["data"])
        #     final_string += f"* {x}\n\n"
        else:
            if x["type"] == "response":
                final_string += "  - {}\n".format(x["data"])
            elif x["type"] == "intent":
                # if "entities" in x.keys():
                #     # print("PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP")
                #     to_add = {}
                #     # print(x["entities"])
                #     # lpo = input("wait")
                #     if len(x["entities"]) > 0:
                #         for y in x["entities"]:
                #             # print("LL", y)
                #             e_name = y["name"]
                #             e_value = y["value"]
                #             to_add[e_name] = e_value
                #         # to_add = '{"' + y["name"] +
                #     # to_write = "* {}{\n\n".format(x["data"]
                #     # print("* {}".format(x["data"]) + str(to_add) + "\n")
                #     # lpo = input("waiter")
                #     if len(to_add.keys()) > 0:
                #         final_string += "* {}".format(x["data"]) + str(to_add) + "\n"
                #     else:
                #         final_string += "* {}".format(x["data"]) + "\n"
                # else:
                final_string += "* {}\n".format(x["data"])
                # #print(x)
                # final_string += "* {}\n".format(x["data"])
        # #print("*"*10)
        # #print(x)
        # if i == length:
        #     if x[:6] == "utter_":
        #         final_string += f"  - {x}\n\n"
        #     else:
        #         final_string += f"* {x}\n\n"
        # else:
        #     if x[:6] == "utter_":
        #         final_string += f"  - {x}\n"
        #     else:
        #         final_string += f"* {x}\n"
        # final_string += f"- {x}\n"
        i += 1
    md_file.write(final_string)
    # final_string = r""""""


def test_write_stories():
    global check_list_of_story
    intents, entities, responses, stories, groups, slots, actions = initialize()
    global test
    md_file = open("stories.md", "w")
    # #print(responses)
    final_string = r""""""
    branches = []
    for group in groups:
        # #print(group.name)
        for story in group.stories:
            story = story_svc.get_story_by_name_(story)
            story = json.loads(story)[0]
            # #print("LLLLLLLLLLLLLL")
            # #print(story)
            # #print(type(story))
            story_name1 = f"\n## {story['name']}\n"
            story_name = f"{story['name']}"
            final_string += story_name1
            md_file.write(final_string)
            final_string = r""""""
            content_list = list(x for x in story["content"]["story"])
            writing_to_md(
                content_list, final_string, md_file, branch_name=story["name"]
            )
            try:
                branches = story["content"]["branches"]
            except:
                pass
            if len(branches) == 0:
                continue
            test = 1
            test_first_branch(branches, final_string, md_file, story_name)
    check_list_of_story = []


# test_write_nlu()
# test_read()
# file1 = open("domain1.yml","r")
# #print(repr(file1.read()))
# test_write_domain()
# test_write_nlu()
# test_write_stories()

# { # "intents:\n  - greet\n  - greet3\nresponses:\n  greet1:\n    - text: "yoo b\n    - buttons:\n      - {}\n  utter_greet:\n    - text: yoo b\n    - buttons:\n      - {}\n  utter_greet1:\n    - text: yoo bas\n    - text: yoo ba\n    - text: yoo b\n    - buttons:\n      - payload: /goodbye\n        title: bye\n
# "intents:\n      - greet\n       - greet3\n      responses:\n    greet1:\n       - text: yoo b\n - buttons:\n    - {}\n  utter_greet:\n  - text: yoo b\n - buttons:\n    - {}\n  utter_greet1:\n  - text: yoo bas\n       - text: yoo ba\n        - text: yoo b\n - buttons:\n    - payload: /goodbye\n   title: bye"
#   "domain": "intents:\n  - greet\n  - goodbye\n  - affirm\n  - deny\n  - mood_great\n  - mood_unhappy\n\nresponses:\n  utter_greet:\n  - text: \"Hey! How are you?\"\n\n  utter_cheer_up:\n  - text: \"Here is something to cheer you up:\"\n    image: \"https://i.imgur.com/nGF1K8f.jpg\"\n\n  utter_did_that_help:\n  - text: \"Did that help you?\"\n\n  utter_happy:\n  - text: \"Great carry on!\"\n\n  utter_goodbye:\n  - text: \"Bye\"",
#   "config": "language: en\npipeline: supervised_embeddings\npolicies:\n  - name: MemoizationPolicy\n  - name: KerasPolicy",
#   "nlu": "## intent:greet\n- hey\n- hello\n- hi\n## intent:goodbye\n- bye\n- goodbye\n- have a nice day\n- see you\n## intent:affirm\n- yes\n- indeed\n## intent:deny\n- no\n- never\n## intent:mood_great\n- perfect\n- very good\n- great\n## intent:mood_unhappy\n- sad\n- not good\n- unhappy",
#   "responses": "## ask name * chitchat/ask_name\n    - my name is Sara, Rasa's documentation bot!\n\n## ask weather * chitchat/ask_weather\n    - it's always sunny where I live",
#   "stories": "## happy path\n* greet\n\n  - utter_greet\n\n* mood_great\n\n  - utter_happy\n\n## sad path 1\n* greet\n\n  - utter_greet\n\n* mood_unhappy\n\n  - utter_cheer_up\n\n  - utter_did_that_help\n\n* affirm\n\n  - utter_happy\n\n## sad path 2\n* greet\n\n  - utter_greet\n\n* mood_unhappy\n\n  - utter_cheer_up\n\n  - utter_did_that_help\n\n* deny\n\n  - utter_goodbye\n\n## say goodbye\n* goodbye\n\n  - utter_goodbye",
#   "force": false,
#   "save_to_default_model_directory": true
# }
