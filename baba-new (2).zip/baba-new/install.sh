apt-get -y update
apt-get -y upgrade
apt-get install -y --upgrade python3
apt-get install -y --upgrade python3-pip
apt-get install -y mongodb
systemctl start mongod
systemctl start mongodb
pip3 install -r requirements.txt
