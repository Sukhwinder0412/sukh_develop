import os
from bson import ObjectId
from os import listdir
from os.path import isfile, join

from flask_cors import CORS, cross_origin
from flask import Flask, request, jsonify
from flask_cors.core import try_match
from flask_talisman import Talisman

import hashlib
import mongoengine
import pymongo
import db.data.mongo_setup as mongo_setup

mongo_setup.global_init("Baba", alias="default")
mongo_setup.global_init("Configurations", alias="config")
import db.services.intent_service as intent_svc
import db.services.language_service as language_svc
import db.services.entity_service as entity_svc
import db.services.action_service as action_svc
import db.services.slots_service as slot_svc
import db.services.config_service as config_svc
import db.services.response_service as response_svc
import db.services.group_service as group_svc
import db.services.conversation_service as conv_svc
import db.services.story_service as story_svc
import db.services.user_service as user_svc
import db.services.regex_service as regex_svc
import db.services.project_config_service as pconfig_svc

import json

# conf = pconfig_svc.get_all_configs()
# print(len(json.loads(conf.to_json())[0]["content"]["channels"]))
import urllib
from train import model_train
import requests
import time
import datetime
import subprocess
import conf


from flask_jwt_extended import (
    JWTManager,
    jwt_required,
    create_access_token,
    get_jwt_identity,
)


def Merge(dict1, dict2):
    return {**dict1, **dict2}


class JSONEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, ObjectId):
            return str(o)
        return json.JSONEncoder.default(self, o)


app = Flask(__name__)
Talisman(app)
cors = CORS(app, resources={r"/.*": {"origins": "*"}})
app.config["CORS_HEADERS"] = "Content-Type"
app.config["JWT_SECRET_KEY"] = "botbaba"  # Change this!
jwt = JWTManager(app)

# LOGIN #
@jwt.expired_token_loader
def my_expired_token_callback():
    return (
        jsonify(
            {
                "success": False,
                "status": 401,
                "sub_status": 42,
                "message": "The token has expired",
            }
        ),
        401,
    )


@app.route("/login", methods=["POST"])
def login():
    if not request.is_json:
        return jsonify({"success": False, "message": "Missing JSON in request"}), 400

    username = request.json.get("username", None)
    password = request.json.get("password", None)
    if not username:
        return jsonify({"success": False, "message": "Missing username parameter"}), 400
    if not password:
        return jsonify({"success": False, "message": "Missing password parameter"}), 400
    # password = hashlib.sha256(password.encode())
    user = user_svc.get_user(username=str(username).lower(), password=str(password))
    
    if user:
        access_token = create_access_token(
            identity=username, expires_delta=datetime.timedelta(days=1)
        )
        conf = pconfig_svc.get_all_configs()
        conf = json.loads(conf.to_json())
        role = user.role
        # myclient = pymongo.MongoClient(
        #     "mongodb+srv://baba:Qwerty123@baba.6fxcw.mongodb.net/Baba?retryWrites=true&w=majority"
        # )
        # db_names = myclient.list_database_names()
        return (
            jsonify(
                {
                    "success": True,
                    "access_token": access_token,
                    "db_names": list(conf[0]["content"]["channels"].keys()),
                    "role":role,
                }
            ),
            200,
        )

    else:
        return jsonify({"success": False, "message": "Bad username or password"}), 401


@app.route("/signup", methods=["POST"])
def signup():
    if not request.is_json:
        return jsonify({"success": False, "message": "Missing JSON in request"}), 400

    username = request.json.get("username", None)
    password = request.json.get("password", None)
    email    = request.json.get("email", None)
    role     = request.json.get("role", None)
    if not username:
        return jsonify({"success": False, "message": "Missing username parameter"}), 400
    if not password:
        return jsonify({"success": False, "message": "Missing password parameter"}), 400
    if not email:
        return jsonify({"success": False, "message": "Missing email parameter"}), 400
    if not role:
        return jsonify({"success": False, "message": "Missing role  parameter"}), 400


    user = user_svc.add_user(username=username, password=password,email=email,role=role)
    if user:
        # access_token = create_access_token(identity=username)
        return jsonify({"success": True, "data": "Acoount created successfully"}), 200

    else:
        return jsonify({"success": False, "message": "Bad username or password"}), 401


# Identity can be any data that is json serializable
# INTENTS #


@app.route("/create_intent", methods=["POST"])
@cross_origin()
@jwt_required
def create_intent1():
    contents = request.get_json()
    output = intent_svc.create_intent(
        name=contents["name"], text=contents["text"], in_stories=contents["in_stories"]
    )
    # print(contents)
    # if output
    # result = {"success": }
    try:
        if type(output) == str:
            result = {"success": False, "message": output}
            return json.dumps(result)
        else:
            result = {"success": True, "data": json.loads(output.to_json())}
            return json.dumps(result)
    except:
        result = {"success": False, "message": output}
        return json.dumps(result)


@app.route("/get_intent_by_name", methods=["POST"])
@cross_origin()
@jwt_required
def get_intent_by_name1():
    contents = request.get_json()
    output = intent_svc.find_intent_by_name(name=contents["name"])
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": True, "message": output}
        return json.dumps(result)


@app.route("/delete_intent/<id>", methods=["DELETE"])
@cross_origin(id)
@jwt_required
def delete_intent1(id):
    contents = request.get_json()
    output = intent_svc.delete_intent(id=id)
    return output


@app.route("/update_intent", methods=["PUT"])
@cross_origin()
@jwt_required
def update_intent1():
    contents = request.get_json()
    output = intent_svc.update_intent(
        id=contents["id"],
        name=contents["name"],
        text=contents["text"],
        in_stories=contents["in_stories"],
    )
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": False, "message": output}
        return json.dumps(result)


@app.route("/set_intent_canonical", methods=["PUT"])
@cross_origin()
@jwt_required
def set_intent_canonical1():
    contents = request.get_json()
    output = intent_svc.set_canonical(id=contents["id"], text=contents["text"])
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": False, "message": output}
        return json.dumps(result)


@app.route("/del_intent_canonical", methods=["PUT"])
@cross_origin()
@jwt_required
def del_intent_canonical1():
    contents = request.get_json()
    output = intent_svc.del_canonical(id=contents["id"])
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": True, "message": output}
        return json.dumps(result)


@app.route("/intent_names", methods=["GET"])
@cross_origin()
@jwt_required
def intent_names1():
    contents = request.get_json()
    output = intent_svc.intent_names()
    try:
        result = {"success": True, "data": json.loads(output)}
        return json.dumps(result)
    except Exception as e:
        result = {"success": False, "message": output}
        return json.dumps(result)


@app.route("/get_all_intents/<language>", methods=["GET"])
@cross_origin()
@jwt_required
def get_all_intents1(language):
    # language = request.args.get('language')
    skip = int(request.args.get("skip")) if request.args.get("skip") != None else None
    limit = (
        int(request.args.get("limit")) if request.args.get("limit") != None else None
    )
    output = intent_svc.get_all_intents(language=language, skip=skip, limit=limit)
    try:
        result = {"success": True, "data": json.loads(output)}
        return json.dumps(result)
    except:
        result = {"success": True, "message": output}
        return json.dumps(result)


@app.route("/intent_search/<name>", methods=["GET"])
@cross_origin()
@jwt_required
def intent_search(name):
    skip = int(request.args.get("skip")) if request.args.get("skip") != None else 0
    limit = int(request.args.get("limit")) if request.args.get("limit") != None else 10
    output = intent_svc.intent_search(name=name, skip=skip, limit=limit)
    try:
        result = {"success": True, "data": json.loads(output)}
        return json.dumps(result)
    except Exception as e:
        print(e)
        result = {"success": True, "message": output}
        return json.dumps(result)


@app.route("/get_intent_by_id", methods=["POST"])
@cross_origin()
@jwt_required
def get_intent_by_id1():
    contents = request.get_json()
    output = intent_svc.get_intent_by_id(id=contents["id"])
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": True, "message": output}
        return json.dumps(result)


@app.route("/del_intent_text", methods=["DELETE"])
@cross_origin()
@jwt_required
def del_intent_text1():
    contents = request.get_json()
    output = intent_svc.del_text(id=contents["id"], text=contents["text"])
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": True, "message": output}
        return json.dumps(result)


# RESPONSES #


@app.route("/create_response", methods=["POST"])
@cross_origin()
@jwt_required
def create_response1():
    contents = request.get_json()
    output = response_svc.create_response(
        name=contents["name"], text=contents["text"], in_stories=contents["in_stories"]
    )
    # print(contents)
    try:
        if type(output) == str:
            result = {"success": False, "message": output}
            return json.dumps(result)
        else:
            result = {"success": True, "data": json.loads(output.to_json())}
            return json.dumps(result)
    except:
        result = {"success": False, "message": output}
        return json.dumps(result)


@app.route("/get_response_by_name", methods=["POST"])
@cross_origin()
@jwt_required
def get_response_by_name1():
    contents = request.get_json()
    output = response_svc.find_response_by_name(name=contents["name"])
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": True, "message": output}
        return json.dumps(result)


@app.route("/response_search/<name>", methods=["GET"])
@cross_origin()
@jwt_required
def response(name):
    # language = request.args.get('language')
    skip = int(request.args.get("skip")) if request.args.get("skip") != None else 0
    limit = int(request.args.get("limit")) if request.args.get("limit") != None else 10
    output = response_svc.response_search(name=name, skip=skip, limit=limit)
    try:
        result = {"success": True, "data": json.loads(output)}
        return json.dumps(result)
    except Exception as e:
        print(e)
        # print("LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL")
        result = {"success": True, "message": output}
        return json.dumps(result)


@app.route("/delete_response/<id>", methods=["DELETE"])
@cross_origin()
@jwt_required
def delete_response1(id):
    contents = request.get_json()
    output = response_svc.delete_response(id=id)
    # print(contents)
    return output


@app.route("/update_response", methods=["PUT"])
@cross_origin()
@jwt_required
def update_response1():
    contents = request.get_json()
    output = response_svc.update_response(
        id=contents["id"],
        name=contents["name"],
        text=contents["text"],
        in_stories=contents["in_stories"],
    )
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": False, "message": output}
        return json.dumps(result)


@app.route("/set_response_canonical", methods=["PUT"])
@cross_origin()
@jwt_required
def set_response_canonical1():
    contents = request.get_json()
    output = response_svc.set_canonical(id=contents["id"], text=contents["text"])
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": True, "message": output}
        return json.dumps(result)


@app.route("/del_response_canonical", methods=["PUT"])
@cross_origin()
@jwt_required
def del_response_canonical1():
    contents = request.get_json()
    output = response_svc.del_canonical(id=contents["id"])
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": True, "message": output}
        return json.dumps(result)


@app.route("/response_names", methods=["GET"])
@cross_origin()
@jwt_required
def response_names1():
    # contents = request.get_json()
    output = response_svc.respone_names()
    # print(contents)
    try:
        result = {"success": True, "data": json.loads((output))}
        return json.dumps(result)
    except:
        result = {"success": True, "message": output}
        return json.dumps(result)


@app.route("/get_all_responses/<language>", methods=["GET"])
@cross_origin()
@jwt_required
def get_all_responses1(language):
    # language = request.args.get('language')
    skip = int(request.args.get("skip")) if request.args.get("skip") != None else None
    limit = (
        int(request.args.get("limit")) if request.args.get("limit") != None else None
    )
    output = response_svc.get_all_responses(language, skip, limit)
    # print(contents)
    try:
        result = {"success": True, "data": json.loads((output))}
        return json.dumps(result)
    except:
        result = {"success": True, "message": output}
        return json.dumps(result)


@app.route("/get_response_by_id/<id>", methods=["GET"])
@cross_origin()
@jwt_required
def get_response_by_id1(id):
    # contents = request.get_json()
    output = response_svc.get_response_by_id(id=id)
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": True, "message": output}
        return json.dumps(result)


# GROUPS #


@app.route("/create_group", methods=["POST"])
@cross_origin()
@jwt_required
def create_group1():
    contents = request.get_json()
    output = group_svc.create_group(
        name=contents["name"],
        stories=contents["stories"],
        status=contents["status"],
        partial_training=contents["partial_training"],
    )
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": False, "message": output}
        return json.dumps(result)


@app.route("/get_group_by_name", methods=["GET"])
@cross_origin()
@jwt_required
def get_group_by_name1():
    contents = request.get_json()
    output = group_svc.find_group_by_name(name=contents["name"])
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": False, "message": output}
        return json.dumps(result)


@app.route("/delete_group/<id>", methods=["DELETE"])
@cross_origin()
@jwt_required
def delete_group1(id):
    contents = request.get_json()
    output = group_svc.delete_group(id=id)
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": False, "message": output}
        return json.dumps(result)


@app.route("/update_group", methods=["PUT"])
@cross_origin()
@jwt_required
def update_group1():
    contents = request.get_json()
    output = group_svc.update_group(
        id=contents["id"],
        name=contents["name"],
        stories=contents["stories"],
        status=contents["status"],
        partial_training=contents["partial_training"],
    )
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": False, "message": output}
        return json.dumps(result)


@app.route("/get_all_groups", methods=["GET"])
@cross_origin()
@jwt_required
def get_all_groups1():
    contents = request.get_json()
    output = group_svc.get_all_groups()
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": False, "message": output}
        return json.dumps(result)


@app.route("/get_group_by_id", methods=["POST"])
@cross_origin()
@jwt_required
def get_group_by_id1():
    contents = request.get_json()
    output = group_svc.get_group_by_id(id=contents["id"])
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": False, "message": output}
        return json.dumps(result)


# STORIES #


@app.route("/create_story", methods=["POST"])
@cross_origin()
@jwt_required
def create_story1():
    contents = request.get_json()
    output = story_svc.create_story(
        name=contents["name"],
        group=contents["group"],
        content=contents["content"],
        actions=contents["actions"],
        slots=contents["slots"],
    )
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": False, "message": output}
        return json.dumps(result)


# @app.route("/get_story_by_name", methods=['POST'])
# @cross_origin()
# @jwt_required
# def get_story_by_name1():
#     contents = request.get_json()
#     output = story_svc.get_story_by_name(name=contents["name"])
#     # print(contents)
#     try:
#         result = {"success": True, "data": json.loads(output)[0]}
#         return json.dumps(result)
#     except:
#         result = {"success": False, "message": output}
#         return json.dumps(result)


@app.route("/delete_story/<id>", methods=["DELETE"])
@cross_origin()
@jwt_required
def delete_story1(id):
    contents = request.get_json()
    output = story_svc.delete_story(id=id)
    # print(contents)
    try:
        return output
    except:
        return json.dumps({"success": False, "message": "error"})


@app.route("/update_story", methods=["PUT"])
@cross_origin()
@jwt_required
def update_story1():
    contents = request.get_json()
    output = story_svc.update_story(
        id=contents["id"],
        name=contents["name"],
        group=contents["group"],
        content=contents["content"],
        actions=contents["actions"],
        slots=contents["slots"],
    )
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": False, "message": output}
        return json.dumps(result)


@app.route("/get_all_stories", methods=["GET"])
@cross_origin()
@jwt_required
def get_all_stories1():
    contents = request.get_json()
    output = story_svc.get_all_stories()
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output)}
        return json.dumps(result)
    except:
        result = {"success": False, "message": output}
        return json.dumps(result)


@app.route("/get_story_by_name/<path:name>", methods=["GET"])
@cross_origin()
@jwt_required
def get_story_by_name1(name):
    # id = request.args.get('id') if request.args.get('id') != None else "en"
    language = (
        request.args.get("language") if request.args.get("language") != None else "en"
    )
    print("language", language)
    output = story_svc.get_story_by_name(name, language)
    # print(type(output))
    try:
        result = {"success": True, "data": json.loads(output)}
        return json.dumps(result)
    except:
        result = {"success": False, "message": output}
        return json.dumps(result)


# @app.route("/get_story_by_name", methods=['GET'])
# @cross_origin()
# @jwt_required
# def get_story_by_name1():
#     id = request.args.get('name') if request.args.get('id') != None else "en"
#     language = request.args.get('language') if request.args.get('language') != None else None
#     output = story_svc.get_story_by_id(id, language)
#     # print(type(output))
#     try:
#         result = {"success": True, "data": json.loads(output)}
#         return json.dumps(result)
#     except:
#         result = {"success": False, "message": output}
#         return json.dumps(result)

# ENTITIES


@app.route("/create_entity", methods=["POST"])
@cross_origin()
@jwt_required
def create_entity1():
    contents = request.get_json()
    output = entity_svc.add_entity(name=contents["name"])
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": False, "message": output}
        return json.dumps(result)


@app.route("/get_entity_by_name", methods=["POST"])
@cross_origin()
@jwt_required
def get_entity_by_name1():
    contents = request.get_json()
    output = entity_svc.find_entity_by_name(name=contents["name"])
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": False, "message": "NO such entity"}
        return json.dumps(result)


@app.route("/delete_entity/<id>", methods=["DELETE"])
@cross_origin()
@jwt_required
def delete_entity1(id):
    contents = request.get_json()
    output = entity_svc.delete_entity(id=id)
    # print(contents)
    try:
        result = {"success": True, "data": output}
        return json.dumps(result)
    except:
        result = {"success": False, "message": "idk"}
        return json.dumps(result)


@app.route("/update_entity", methods=["PUT"])
@cross_origin()
@jwt_required
def update_entity1():
    contents = request.get_json()
    output = entity_svc.update_entity(id=contents["id"], name=contents["name"])
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": False, "message": output}
        return json.dumps(result)


@app.route("/get_all_entities", methods=["GET"])
@cross_origin()
@jwt_required
def get_all_entities1():
    contents = request.get_json()
    output = entity_svc.get_all_entities()
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": False, "message": output}
        return json.dumps(result)


@app.route("/get_entity_by_id", methods=["POST"])
@cross_origin()
@jwt_required
def get_entity_by_id1():
    contents = request.get_json()
    output = entity_svc.get_entity_by_id(id=contents["id"])
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": False, "message": output}
        return json.dumps(result)


# SLOTS #


@app.route("/slots", methods=["POST"])
@cross_origin()
@jwt_required
def create_slot1():
    contents = request.get_json()
    print(contents)
    output = slot_svc.create_slot(contents)
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": False, "message": output}
        return json.dumps(result)


# @app.route("/get_slot_by_name", methods=['POST'])
# @cross_origin()
# @jwt_required
# def get_slot_by_name1():
#     contents = request.get_json()
#     output = slot_svc.find_slot_by_name(name=contents["name"])
#     # print(contents)
#     try:
#         result = {"success": True, "data": json.loads(output.to_json())}
#         return json.dumps(result)
#     except:
#         result = {"success": False, "message": output}
#         return json.dumps(result)


@app.route("/slots/<id>", methods=["DELETE"])
@cross_origin()
@jwt_required
def del_slot1(id):
    contents = request.get_json()
    output = slot_svc.delete_slot(id=id)
    # print(contents)
    try:
        result = {"success": True, "data": output}
        return json.dumps(result)
    except:
        result = {"success": False, "message": "idk"}
        return json.dumps(result)


# @app.route("/update_slot", methods=['POST'])
# @cross_origin()
# @jwt_required
def update_slot1():
    contents = request.get_json()
    output = slot_svc.update_slot(
        id=contents["id"],
        name=contents["name"],
        content=contents["content"],
        typename=contents["typename"],
        initial_value=contents["initial_value"],
        initial_value_float=contents["initial_value_float"],
        categories=contents["categories"],
        min_value=contents["nim_value"],
        max_value=contents["max_value"],
    )
    # print(contents)
    try:
        result = {"success": True, "data": output}
        return json.dumps(result)
    except:
        result = {"success": False, "message": "idk"}
        return json.dumps(result)


@app.route("/slots", methods=["GET"])
@cross_origin()
@jwt_required
def get_all_slots1():
    contents = request.get_json()
    output = slot_svc.get_all_slots()
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": False, "message": "idk"}
        return json.dumps(result)


@app.route("/slots/<id>", methods=["GET"])
@cross_origin()
@jwt_required
def get_slot_by_id1():
    contents = request.get_json()
    output = slot_svc.get_slot_by_id(id=contents["id"])
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": False, "message": "idk"}
        return json.dumps(result)


# TRAIN #
# is_training1 = False


@app.route("/model_train", methods=["POST"])
@cross_origin()
@jwt_required
def model_train1():
    contents = request.get_json()
    result = model_train(contents["languages"], contents["port"])
    if result:
        is_training1 = False
    # print(result)
    if str(result) == "200":
        return json.dumps({"status": True, "data": "Training Complete"})
    else:
        return json.dumps({"status": False, "data": "Training Failed"})


@app.route("/models/<language>", methods=["GET"])
@cross_origin()
@jwt_required
def list_models(language):
    final = []
    fname = f"./models/"
    filenames = [f for f in listdir(fname) if isfile(join(fname, f))]
    # _, _, filenames = next(os.walk(fname))
    for f in filenames:
        if f.startswith(language):
            final.append(f)

    return final


@app.route("/models", methods=["PUT"])
@cross_origin()
@jwt_required
def load_model():
    contents = request.get_json()
    fname = f"./models/{contents['filename']}"
    port = contents["port"]
    url = f"https://nlp.kochartech.com:{port}/model"
    response = requests.request("PUT", url, data=json.dumps({"model_file": fname}))

    return response.status_code


# @app.route("/is_training", methods=['GET'])
# @cross_origin()
# @jwt_required
# def is_training():
#     # global is_training1
#     # print(is_training1)
#     return json.dumps({"status": is_training1})


@app.route("/status", methods=["GET"])
@cross_origin()
@jwt_required
def status():
    url = "http://nlp.kochartech.com:5005/status"
    # global is_training1
    # response = requests.request("GET", url)
    response = requests.get(url)
    # print(response.json())
    return response.json()


## CONVERSATIONS


@app.route("/conversations", methods=["GET"])
@cross_origin()
@jwt_required
def conversations1():
    # conversations = request.get_json()
    output = conv_svc.get_all_conversations()
    output = JSONEncoder().encode(output)
    try:
        result = {"success": True, "data": json.loads(output)}
        return json.dumps(result)
    except:
        result = {"success": False, "message": output}
        return json.dumps(result)


@app.route("/conversations/<sender_id>", methods=["GET"])
@cross_origin()
@jwt_required
def conversation_id(sender_id):
    output = conv_svc.get_conversation_by_id(sender_id=sender_id)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except Exception as e:
        print(e)
        result = {"success": False, "message": output}
        return json.dumps(result)


@app.route("/conversations/specific", methods=["GET"])
@cross_origin()
@jwt_required
def conversation():
    time_start = request.args.get("ts")
    time_end = request.args.get("te")
    sender_id = request.args.get("senderId")
    output = conv_svc.get_conversation(sender_id=sender_id, t1=time_start, t2=time_end)
    try:
        result = {"success": True, "data": json.loads(output)}
        return json.dumps(result)
    except Exception as e:
        print(e)
        result = {"success": False, "message": output}
        return json.dumps(result)


@app.route("/utterances", methods=["GET"])
@cross_origin()
@jwt_required
def utterances():
    # conversations = request.get_json()
    output = conv_svc.get_all_utterances()
    output = JSONEncoder().encode(output)
    try:
        result = {"success": True, "data": json.loads(output)}
        return json.dumps(result)
    except:
        result = {"success": False, "message": output}
        return json.dumps(result)


# LANGUAGES #


@app.route("/languages", methods=["POST"])
@cross_origin()
@jwt_required
def add_language1():
    contents = request.get_json()
    output = language_svc.add_language(
        name=contents["name"],
        code=contents["code"],
        port=contents["port"],
        channel=contents["channel"],
    )
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": False, "message": output}
        return json.dumps(result)


@app.route("/languages", methods=["GET"])
@cross_origin()
@jwt_required
def get_all_languages1():
    # contents = request.get_json()
    # print(contents)
    output = language_svc.get_all_languages()
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": False, "message": output}
        return json.dumps(result)


@app.route("/languages", methods=["DELETE"])
@cross_origin()
@jwt_required
def del_language1():
    contents = request.get_json()
    # print(contents)
    output = language_svc.delete_language(name=contents["name"])
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": True, "message": output}
        return json.dumps(result)


# ACTIONS #


@app.route("/actions", methods=["POST"])
@cross_origin()
@jwt_required
def add_action1():
    contents = request.get_json()
    # print(contents)
    output = action_svc.add_action(name=contents["name"])
    # print(contents)
    with open("/home/ubuntu/rasa/rasa/actions.py", "w") as f:
        f.write(contents["file"])
    Fi = open("/home/ubuntu/rasa/rasa/actions.py", "r")
    f = Fi.read()
    Fi.close()
    try:
        result = {"success": True, "data": json.loads(output.to_json()), "file": str(f)}
        return json.dumps(result)
    except:
        result = {"success": True, "message": output}
        return json.dumps(result)


# @app.route("/actions", methods=['POST'])
# @cross_origin()
# @jwt_required
# def add_action1():
#     contents = request.get_json()
#     # print(contents)
#     output = action_svc.add_action(name = contents["name"])
#     # print(contents)
#     with open("/home/ubuntu/rasa/rasa/actions.py", "w") as f:
#         f.write(contents["file"])
#     Fi =  open("/home/ubuntu/rasa/rasa/actions.py", "r")
#     f = Fi.read()
#     Fi.close()
#     try:
#         result = {"success": True, "data": json.loads(output.to_json()), "file": str(f)}
#         return json.dumps(result)
#     except:
#         result = {"success": False, "message": output}
#         return json.dumps(result)


@app.route("/actions", methods=["GET"])
@cross_origin()
@jwt_required
def get_all_actions1():
    # contents = request.get_json()
    # print(contents)
    output = action_svc.get_all_actions()
    # print(contents)
    Fi = open("/home/ubuntu/rasa/rasa/actions.py", "r")
    f = Fi.read()
    Fi.close()

    try:
        result = {"success": True, "data": output.to_json(), "file": str(f)}
        return json.dumps(result)
    except:
        result = {"success": False, "message": output}
        return json.dumps(result)


@app.route("/actions/<id>", methods=["DELETE"])
@cross_origin()
@jwt_required
def del_action1(id):
    # contents = request.get_json()
    # print(contents)
    output = action_svc.del_action(id=id)
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": True, "message": output}
        return json.dumps(result)


# REGEX #


@app.route("/regex", methods=["POST"])
@cross_origin()
@jwt_required
def add_regex1():
    contents = request.get_json()
    # print(contents)
    output = regex_svc.add_regex(name=contents["name"], text=contents["text"])
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": True, "message": output}
        return json.dumps(result)


@app.route("/regex", methods=["PUT"])
@cross_origin()
@jwt_required
def update_regex1():
    contents = request.get_json()
    # print(contents)
    output = regex_svc.update_regex(
        id=contents["id"], name=contents["name"], text=contents["text"]
    )
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": True, "message": output}
        return json.dumps(result)


# @app.route("/actions", methods=['POST'])
# @cross_origin()
# @jwt_required
# def add_action1():
#     contents = request.get_json()
#     # print(contents)
#     output = action_svc.add_action(name = contents["name"])
#     # print(contents)
#     with open("/home/ubuntu/rasa/rasa/actions.py", "w") as f:
#         f.write(contents["file"])
#     Fi =  open("/home/ubuntu/rasa/rasa/actions.py", "r")
#     f = Fi.read()
#     Fi.close()
#     try:
#         result = {"success": True, "data": json.loads(output.to_json()), "file": str(f)}
#         return json.dumps(result)
#     except:
#         result = {"success": False, "message": output}
#         return json.dumps(result)


@app.route("/regex", methods=["GET"])
@cross_origin()
@jwt_required
def get_all_regex1():
    # contents = request.get_json()
    # print(contents)
    output = regex_svc.get_all_regex()
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": False, "message": output}
        return json.dumps(result)


@app.route("/regex/<id>", methods=["DELETE"])
@cross_origin()
@jwt_required
def del_regex1(id):
    # contents = request.get_json()
    # print(contents)
    output = regex_svc.delete_regex(id=id)
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": True, "message": output}
        return json.dumps(result)


# Configs #


@app.route("/configs", methods=["POST"])
@cross_origin()
@jwt_required
def add_config():
    contents = request.get_json()
    # print(contents)
    output = config_svc.add_config(
        language=contents["name"], content=contents["content"]
    )
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": True, "message": output}
        return json.dumps(result)


@app.route("/configs", methods=["GET"])
@cross_origin()
@jwt_required
def get_all_configs1():
    # contents = request.get_json()
    # print(contents)
    output = config_svc.get_all_configs()
    # print(contents)
    try:
        result = {"success": True, "data": json.loads(output.to_json())}
        return json.dumps(result)
    except:
        result = {"success": False, "message": output}
        return json.dumps(result)


@app.route("/analytics", methods=["GET"])
@cross_origin()
@jwt_required
def analytics():
    # contents = request.get_json()
    # print(contents)
    data = {}
    output = conv_svc.getCount()
    data["conversations"] = output
    output = entity_svc.getCount()
    data["entities"] = output
    output = intent_svc.getCount()
    data["intents"] = output
    output = response_svc.getCount()
    data["responses"] = output
    output = story_svc.getCount()
    data["stories"] = output
    output = group_svc.getCount()
    data["groups"] = output
    output = language_svc.getCount()
    data["languages"] = output
    output = slot_svc.getCount()
    data["slots"] = output - 1

    # print(contents)
    try:
        result = {"success": True, "data": data}
        return json.dumps(result)
    except:
        result = {"success": False, "message": output}
        return json.dumps(result)


@app.route("/nlg", methods=["POST"])
@cross_origin()
# @jwt_required
def generate_NL():
    contents = request.get_json()
    print(contents)
    aliases = contents["aliases"]
    slots = contents["slots"]
    master = contents["master"]
    NLG_file = "NLG_generator.kochar"
    NLG_output = "./nlg_output"
    with open(NLG_file, "w") as f:
        f.write(slots + "\n" + aliases + "\n" + master)
    subprocess.call(
        "python3 " + "-m " + "chatette " + str(NLG_file) + " -o " + "./output -f",
        shell=True,
    )
    # time.sleep(1)
    nlg_j = open("./output/train/output.json", "r")
    nlg_json = json.load(nlg_j)
    return json.dumps(nlg_json)


#
# NLG_file = "NLG_generator.kochar"


@app.route("/nlg", methods=["PUT"])
@cross_origin()
@jwt_required
def nlg_intents1():
    contents = request.get_json()
    for x in contents:
        output = intent_svc.nlg_intents(name=x["name"], text=x["text"])
    # print(contents)
    # if output
    # result = {"success": }
    try:
        if type(output) == str:
            result = {"success": False, "message": output}
            return json.dumps(result)
        else:
            result = {"success": True, "data": json.loads(output.to_json())}
            return json.dumps(result)
    except:
        result = {"success": False, "message": output}
        return json.dumps(result)


## CHANNELS/PROJECTS


@app.route("/channels", methods=["POST"])
@cross_origin()
@jwt_required
def create_channel():
    try:
        contents = request.get_json()
        # mongo_setup.global_init("Configurations")
        conf = pconfig_svc.get_all_configs()
        conf = json.loads(conf.to_json())
        if contents["db_name"] in conf[0]["content"]["channels"].keys():
            return (
                json.dumps({"success": False, "message": "Channel already exists"}),
                400,
            )
        mongo_setup.global_init(contents["db_name"], "basic")
        _ = language_svc.add_language(name="English", code="en")
        no_of_channels = len(conf[0]["content"]["channels"])
        english_port = contents["port"]
        conf[0]["content"]["channels"] = Merge(
            conf[0]["content"]["channels"], {contents["db_name"]: {"en": english_port}}
        )
        conf = pconfig_svc.add_config(conf[0]["name"], conf[0]["content"])
        return json.dumps({"success": True, "data": "New channel created"})
    except Exception as e:
        return json.dumps({"success": False, "message": str(e)})


@app.route("/channels", methods=["PUT"])
@cross_origin()
@jwt_required
def channels1():
    try:
        contents = request.get_json()
        mongo_setup.global_init(contents["db_name"], alias="default")
        return json.dumps({"success": True, "data": "connected"})
    except Exception as e:
        return json.dumps({"success": False, "message": e}), 400


@app.route("/channels", methods=["GET"])
@cross_origin()
@jwt_required
def get_channels():
    try:
        conf = pconfig_svc.get_all_configs()
        conf = json.loads(conf.to_json())
        return json.dumps({"success": True, "data": conf[0]["content"]["channels"]})
    except Exception as e:
        return json.dumps({"success": False, "message": str(e)}), 400


@app.route("/channels", methods=["DELETE"])
@cross_origin()
@jwt_required
def del_channel():
    try:
        contents = request.get_json()
        conf = pconfig_svc.get_all_configs()
        conf = json.loads(conf.to_json())
        c = conf[0]["content"]["channels"].copy()
        b = c.pop(contents["channel"], "No Key found")
        # print(c.pop(contents["channel"], 'No Key found'))
        conf[0]["content"]["channels"] = c
        conf = pconfig_svc.add_config(conf[0]["name"], conf[0]["content"])
        conf = pconfig_svc.get_all_configs()
        conf = json.loads(conf.to_json())
        myclient = pymongo.MongoClient(
            "mongodb+srv://baba:Qwerty123@baba.6fxcw.mongodb.net/Baba?retryWrites=true&w=majority"
        )
        l = myclient.drop_database(contents["channel"])
        return json.dumps(
            {"success": True, "data": list(conf[0]["content"]["channels"].keys())}
        )
    except Exception as e:
        return json.dumps({"success": False, "message": str(e)}), 400


## ! models

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=8888)
# subprocess.call("python3 "+ "-m "+ "chatette "+ str(NLG_file)+ " -o " + "/home/shubhamwani/Desktop/output ", shell=True)