from flask_cors import CORS, cross_origin
from polyglot.detect import Detector
from flask import Flask, request, abort
import json
import requests
import redis

r = redis.Redis(host="localhost", port=6379, db=0)
app = Flask(__name__)

# cors = CORS(app, resources={r'/messa*': {'origins': '*'}})
# app.config['CORS_HEADERS'] = 'Content-Type'
numbers = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "#"]
languageMapping = {
    "English": "http://nlp.kochartech.com:5005/webhooks/rest/webhook",
    "Arabic": "http://nlp.kochartech.com:5006/webhooks/rest/webhook",
}
message = []


def InputChannel1(contents):
    global languageMapping
    global numbers
    global message
    contents["message"] = (
        "/" + contents["message"]
        if contents["message"] in numbers
        else contents["message"]
    )
    #   if 'sender' and 'message' not in contents.keys():
    #        return '', 403
    print(contents["message"])
    idLanguage = r.get(contents["sender"])
    print(idLanguage)
    if idLanguage:
        url = languageMapping[idLanguage.decode("utf-8")]
        print("url", url)
        print(contents)
        print("data", json.dumps(contents))
        response = requests.post(url, json=contents)
        # print(list(response.json()))
        print("url", url)
        # jk = input('jk')
        message = response.json()
        return ""
    else:
        try:
            language = (
                "English"
                if "English"
                in Detector(contents["message"]).languages[0].decode("utf-8")
                else "Arabic"
            )
            if language:
                url = languageMapping[language]
        except Exception as e:
            print(e)
            url = languageMapping["English"]
        response = requests.post(url, data=json.dumps(contents))
        message = response.json()
        return ""


@app.route("/message", methods=["POST"])
@cross_origin()
def InputChannel(contents=None):
    global message
    global r
    try:
        contents = request.get_json()
    except:
        contents["message"] = (
            "/" + contents["message"]
            if contents["message"] in numbers
            else contents["message"]
        )
        if "sender" and "message" not in contents.keys():
            return "", 403
        idLanguage = r.get(contents["sender"])
        if idLanguage:
            url = languageMapping[idLanguage.decode("utf-8")]
            response = requests.post(url, data=json.dumps(contents))
            # print(list(response.json()))
            # jk = input('jk')
            message = json.dumps(response.json())
            return ""
        else:
            try:
                language = (
                    "English"
                    if "English"
                    in Detector(contents["message"]).languages[0].decode("utf-8")
                    else "Arabic"
                )
                if language:
                    url = languageMapping[language]
            except Exception as e:
                print(e)
                url = languageMapping["English"]
            response = requests.post(url, data=json.dumps(contents))
            message = response.json()
            return ""

    contents["message"] = (
        "/" + contents["message"]
        if contents["message"] in numbers
        else contents["message"]
    )
    #    if 'sender' and 'message' not in contents.keys():
    #       return '', 403
    idLanguage = r.get(contents["sender"])
    if idLanguage:
        url = languageMapping[idLanguage.decode("utf-8")]
        response = requests.post(url, data=json.dumps(contents))
        # print(list(response.json()))
        # jk = input('jk')
        con = (
            f"http://nlp.kochartech.com:5005/conversations/{contents['sender']}/tracker"
        )
        print(con)
        re = requests.get(con)
        print(re.json())  # ['latest_message']['intent']['name'])
        return json.dumps(response.json())
    else:
        try:
            language = (
                "English"
                if "English"
                in Detector(contents["message"]).languages[0].decode("utf-8")
                else "Arabic"
            )
            if language:
                url = languageMapping[language]
        except Exception as e:
            print(e)
            url = languageMapping["English"]
        response = requests.post(url, data=json.dumps(contents))
        message = response.json()
        con = (
            f"http://nlp.kochartech.com:5005/conversations/{contents['sender']}/tracker"
        )
        print(con)
        re = requests.get(con)
        print(re.json())
        return json.dumps(response.json())


@app.route("/action", methods=["POST"])
# @cross_origin()
def actions():
    global message
    contents = request.get_json()
    print(contents)
    InputChannel1(contents=dict(contents))
    # name and text(python file text)
    # message = contents["message"]
    return ""


@app.route("/message1", methods=["GET"])
@cross_origin()
def output():
    global message
    message1 = message
    message = []
    try:
        return json.dumps(message1)
    except:
        return json.dumps(message1)


# @app.route('/redis', methods = ['POST'])
# def red():
#     contents = request.get_json()
#     r.set(contents["sender"], contents["language"])
#     return ""

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5001)
