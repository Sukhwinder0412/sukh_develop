import urllib 
from mongoengine import connect
def conn():
    username = urllib.parse.quote_plus('Baba')
    password = urllib.parse.quote_plus("Shu@3d2y")
    connect('Baba', username='Baba', password='Shu@3d2y', authentication_source='admin', host=f"mongodb+srv://{username}:{password}@baba.6fxcw.mongodb.net/Baba?retryWrites=true&w=majority")
conn()
print(t)