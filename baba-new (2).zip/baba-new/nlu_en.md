#lang: en


## intent:0
- 0

## intent:1
- 1

## intent:2
- 2

## intent:3
- 3

## intent:4
- 4

## intent:5
- 5

## intent:6
- 6

## intent:Name
- My name is [Shubham](Name)
- My name is [Sukhwinder](Name)
- My name is [Arun](Name)
- My name is [Upma](Name)

## intent:whatsapp_number
- whatsapp starter
- whatsapp started
- whatsapp
- whatsapp_number

## intent:omanuna
- oman

## intent:FAQ
- FAQ

## intent:#
- hi
- #

## intent:greet
- 

## intent:assist
- help

## intent:utter_name09
- Dumbwani

## intent:name_story
- Name_story

## intent:Bored
- I am getting bored
- bored

## intent:user.cantSleep
- I can't sleep

## intent:9
- 9