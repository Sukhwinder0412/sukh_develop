#lang: hi


## intent:greet1
- namaste
- namaskar

## intent:indian_greet
- नमस्ते