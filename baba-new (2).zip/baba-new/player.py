# -*- coding: utf-8 -*-
import datetime
import re
import json
import csv
import config
import pyodbc
import nlp_intent_entity
from nlp_intent_entity import process_entity
from nlp_intent_entity import process_intent
from nltk.stem.lancaster import LancasterStemmer
import traceback
from importlib import reload
from spell_checker import get_suggestions

host=config.DATABASE_CONFIG['host']
user=config.DATABASE_CONFIG['user']
password=config.DATABASE_CONFIG['password']
db=config.DATABASE_CONFIG['dbname']
port=config.DATABASE_CONFIG['port']
driver=config.DATABASE_CONFIG['driver']

stemmer = LancasterStemmer()



def reload_train():
    reload(nlp_intent_entity)
    from nlp_intent_entity import process_entity
    from nlp_intent_entity import process_intent

def stem_entity(user_input):
    # user_input = user_input.split(" ")
    # words = [stemmer.stem(w.lower()) for w in user_input]
    # stemmed = ' '.join(words)
    return user_input

def nlp_json(wid,user_input):
    pi= process_intent(user_input)
    real_input =user_input
    user_input =user_input.lower().strip().split()
    inpp =[w for w in user_input if len(w)<20]
    inpp =" ".join(inpp)
    user_input =inpp
    try:
        if pi["Intent"]!=  "null":
            intent_with_locale = pi["Intent"].split("-")
            intent =  intent_with_locale[0]
            locale= intent_with_locale[1]
            confidence =  pi["Score"]
            confidence =  float(confidence)
            confidence =  round(confidence, 2)
        else:
            intent =  "Irrelevant"
            locale = "en"
            confidence =  1.0
    except Exception as e:
        e= str(e)
        print(e)
        intent,confidence,locale ="Irrelevant",1.0,"en"	
    try:
        pe =  process_entity(user_input)
        if pe :
            # print("first attempt")
            entity_with_locale =  pe["Entity"]
            value_with_locale =  pe["Value"]
            entity_with_locale =  entity_with_locale.split("-")
            e_locale =  entity_with_locale[0]
            entity =  entity_with_locale[1]
            value_with_locale =  value_with_locale.split("-")
            v_locale =  value_with_locale[0]
            value =  value_with_locale[1]

        else:
            # print("second attempt")
            corrected_input = get_suggestions(user_input)

            pe = process_entity(corrected_input)
            if pe :
                entity_with_locale =  pe["Entity"]
                value_with_locale =  pe["Value"]
                entity_with_locale =  entity_with_locale.split("-")
                e_locale =  entity_with_locale[0]
                entity =  entity_with_locale[1]
                value_with_locale =  value_with_locale.split("-")
                v_locale =  value_with_locale[0]
                value =  value_with_locale[1]
            else:
                entity = "Null"
                value = "Null"
                e_locale =  "Null"
    except Exception as e:
        e= str(e)
        print(e)
        entity = "Null"
        value = "Null"
        e_locale =  "Null"
    result =  {"workspace":wid,"intents": [{"intent": intent,"confidence": confidence,"intent_locale":locale}],"entities": [{"entity": entity,"value": value,"entity_locale":e_locale}],"input": {"text": real_input}}
    result =  json.dumps(result,sort_keys= False, indent= 4,ensure_ascii= False)
    return result
class Funcs(object):
    def db_query(self,q1,q2):
        query = []
        try:
            cur = pyodbc.connect('DRIVER='+driver+';SERVER='+host+','+port+';DATABASE='+db+';UID='+user+';PWD='+password).cursor()
            cur.execute(q1,q2)
            query = cur.fetchall()
            print(query)
        except :
            cur.rollback()
        return query 

    def irrelevant(self,user_input,workspace):
        dialog_node = "0"
        parent_node = "-1"
        condition = "-1"
        intent = "Irrelevant"
        entity_save =False
        regex = r'[\u0600-\u06FF]+'
        malayalam = r'[\u0D00-\u0D7F]+'
        bengali = r'[\u0980-\u09FF]+'
        if re.search(regex, user_input)!=None:
            intent_locale = "ar"
        elif re.search(malayalam, user_input)!=None:
            intent_locale ="ml"
        elif re.search(bengali, user_input)!=None:
            intent_locale ="bn"
        else:
            intent_locale = "en"
        sql = "{CALL dbo.getIntentDetails (?,?,?)}"
        params=((intent,intent_locale,workspace))
        get_intent_id = self.db_query(sql, params)
        intent_id =  ""
        lang_id =  ""
        if get_intent_id :
            intent_id = get_intent_id[0][0]
            lang_id = get_intent_id[0][1]
        
        
        sql = "{CALL dbo.getIntentChildDialog (?,?,?)}"
        params = (intent_id,lang_id,parent_node)
        print(params)
        get_dialog = self.db_query(sql, params)
        if get_dialog:
            dialog_node = get_dialog[0][0]
            dialog = get_dialog[0][1]
            parent_node =get_dialog[0][2]
            condition =get_dialog[0][3]
            entity_save =get_dialog[0][4]
        else:
            if intent_locale == "ar":
                dialog = "المستخدم لعدم الرد"
            elif intent_locale =="ml":
                dialog ="മറുപടി നൽകാത്ത ഉപയോക്താവ്"
            elif intent_locale =="bn":
                dialog ="কোন উত্তর নেই ব্যবহারকারী"
            elif intent_locale == "en":
                dialog ="NO_REPLY"
        
        return dialog,dialog_node, parent_node, condition,entity_save



def switch_or_repeat(workspace,contextArr,entity,value,parent_node,entity_locale,intent_id,lang_id,confidence,inp):
    null_context_variables = False
    init=Funcs()
    # if entity_locale=="ar":
    # 				value1 =str('N')+"'"+str(value)+"'"
    # else:
    # 	value1="'"+value+"'"

    value1 =str('N')+"'"+str(value)+"'"
    cur = pyodbc.connect('DRIVER='+driver+';SERVER='+host+','+port+';DATABASE='+db+';UID='+user+';PWD='+password).cursor()

    sql="select ed.e_id ,ed.lang_id,e.id from entities as e left join entity_details as ed on e.id=ed.entity_id left join languages as l on l.id=e.lang_id  where e.name ='"+entity+"' and ed.e_value="+value1+" and l.locale= '"+entity_locale+"' and e.w_id='"+workspace+"'"
    print(sql)
    cur.execute(sql)
    entityDetails = cur.fetchall()
    print("ennnn")
    print(entityDetails)
    parent_node_temp = -1

    if entityDetails:
        print("sora")
        entity_value_id = entityDetails[0][0]
        entity_locale_id = entityDetails[0][1]
        entity_name_id = entityDetails[0][2]
        sql = "{CALL dbo.GetDialog (?,?,?,?,?)}"

        params = (intent_id,lang_id,entity_value_id,parent_node_temp,entity_name_id)
        print(params)
        dQuery = init.db_query(sql, params)	
        print(dQuery)
        if dQuery :
            print("sorb")
            dialog_node = dQuery[0][0]
            dialog = dQuery[0][1]
            if "%%%%NLPERROR" in dialog:
                loc = dialog.find("%%%%NLPERROR")
                dialog = dialog[loc+12:]
            parent_node =dQuery[0][2]
            condition =dQuery[0][3]
            entity_save =dQuery[0][4]
            null_context_variables = True
        

        else:
            print("sorc")						
            sql = "{CALL dbo.GetENameDialog (?,?,?,?)}"
            params = (intent_id,lang_id,parent_node_temp,entity_name_id)
            print(params)
            dQuery = init.db_query(sql, params)
            print(dQuery)
            if dQuery:
                print("sord")
                dialog_node = dQuery[0][0]
                dialog = dQuery[0][1]
                if "%%%%NLPERROR" in dialog:
                    loc = dialog.find("%%%%NLPERROR")
                    dialog = dialog[loc+12:]
                parent_node =dQuery[0][2]
                condition =dQuery[0][3]
                entity_save =dQuery[0][4]
                null_context_variables = True
            else:
                print("sore")
                if confidence > 0.70:
                    sql = "{CALL dbo.getIntentChildDialog (?,?,?)}"
                    params = (intent_id,lang_id,parent_node_temp)
                    print(params)
                    get_dialog = init.db_query(sql, params)
                    print(get_dialog)
                    if get_dialog:
                        print("sorf")
                        entity = "no_entity"
                        value = "no_value"
                        entity_locale = "no_entity_locale"
                        dialog_node = get_dialog[0][0]
                        dialog = get_dialog[0][1]
                        if "%%%%NLPERROR" in dialog:
                            loc = dialog.find("%%%%NLPERROR")
                            dialog = dialog[loc+12:]
                        parent_node =get_dialog[0][2]
                        condition = get_dialog[0][3]
                        entity_save = False
                        null_context_variables = True
                    # else:
                    # 	dialog,dialog_node, parent_node, condition,entity_save = init.irrelevant(inp,workspace)


                    else:
                        print("sorg")
                        sql ="{CALL dbo.getChildDialog (?)}"
                        params = (parent_node)
                        print(params)
                        dialogQuery =init.db_query(sql, params)	
                        print(dialogQuery)
                        if dialogQuery:
                            print("sorh")
                            dialog_node = dialogQuery[0][0]
                            dialog = dialogQuery[0][1]
                            if "%%%%NLPERROR" in dialog:
                                loc = dialog.find("%%%%NLPERROR")
                                dialog = dialog[loc+12:]
                            parent_node =dialogQuery[0][2]
                            condition =dialogQuery[0][3]
                            entity_save = dialogQuery[0][4]
                            null_context_variables = False
                        else:
                            print("sori")
                            dialog,dialog_node, parent_node, condition,entity_save = init.irrelevant(inp,workspace)

                            null_context_variables = False
                else:
                    print("sorg")
                    sql ="{CALL dbo.getChildDialog (?)}"
                    params = (parent_node)
                    print(params)
                    dialogQuery =init.db_query(sql, params)	
                    print(dialogQuery)
                    if dialogQuery:
                        print("sorh")
                        dialog_node = dialogQuery[0][0]
                        dialog = dialogQuery[0][1]
                        if "%%%%NLPERROR" in dialog:
                            loc = dialog.find("%%%%NLPERROR")
                            dialog = dialog[loc+12:]
                        parent_node =dialogQuery[0][2]
                        condition =dialogQuery[0][3]
                        entity_save = dialogQuery[0][4]
                        null_context_variables = False
                    else:
                        print("sori")
                        dialog,dialog_node, parent_node, condition,entity_save = init.irrelevant(inp,workspace)

                        null_context_variables = False
    if null_context_variables == True:
        print("sorj")
        typeofcontext = "context" 
        get_current_context = init.db_query("select name from context where w_id =? and type=?",(workspace,typeofcontext))
        print(get_current_context)
        if get_current_context:
            for gc in get_current_context:
                currentContext = gc[0]					
                for key,value in contextArr.items():
                    if key == currentContext:
                        contextArr[key]="Null"
    return dialog_node,dialog,parent_node,condition,entity_save


def opt(dbQueryOutput,workspace,contextArr,entity,value,inp,parent_node,entity_locale,intent_id,lang_id,confidence):
    conditionId = dbQueryOutput[0][2]
    init=Funcs()
    print("datecheck1")
    print("dbQueryOutput", dbQueryOutput)
    print("workspace", workspace)
    print("contextArr", contextArr)
    print("entity", entity)
    print("value", value)
    print("inp", inp)
    print("parent_node", parent_node)
    print("entity_locale", entity_locale)
    print("intent_id", intent_id)
    print("lang_id", lang_id)
    print("confidence", confidence)
    if conditionId != '-1':
        print("opta")
        ContextnameParams = (workspace,conditionId)
        ContextnameSql = "{CALL dbo.getContextDetails(?,?)}"
        get_current_context = init.db_query(ContextnameSql,ContextnameParams)
        print("get_current_context: ", get_current_context)
        context_name = get_current_context[0][0]
        print("context_name: ", context_name)
        contextValue = contextArr[context_name]
        if contextValue != "Null":
            print("optb")	
            for d in dbQueryOutput:							
                if contextValue in d:
                    print("optc")
                    dialog_node = d[0]
                    dialog = d[1]
                    if "%%%%NLPERROR" in dialog:
                        loc = dialog.find("%%%%NLPERROR")
                        dialog = dialog[loc+12:]
                    parent_node =d[2]
                    condition =d[3]
                    entity_save =d[4]
                    break
                else:
                    print("optd")
                    dialog_node = dbQueryOutput[0][0]
                    dialog = dbQueryOutput[0][1]
                    if "%%%%NLPERROR" in dialog:
                        loc = dialog.find("%%%%NLPERROR")
                        dialog = dialog[loc+12:]
                    parent_node =dbQueryOutput[0][2]
                    condition =dbQueryOutput[0][3]
                    entity_save =dbQueryOutput[0][4]

        else:
            print("opte")
            context_type = get_current_context[0][1]
            context_validation = get_current_context[0][2]

            if "@entity" in context_validation:
                print("optf")
                print("datecheck", inp)
                context_validation_array =context_validation.split("~")
                context_entity = context_validation_array[1]
                file= open("workspaces/"+workspace+"/entity_model/entities.csv", "r")
                reader = csv.reader(file)
                flag=False
                entt=entity_locale+"-"+context_entity
                inp =stem_entity(inp)
                for line in reader:
                    if entt in line and inp in line:
                        print("optg")
                        ggg=line[0].split("-")
                        contextArr[context_name] = ggg[1]
                        contextValue2 =contextArr[context_name]	
                        flag = True
                        
                if flag == True:
                    print("opth")
                    if contextValue2 != "Null":
                        print("opti")		
                        for d in dbQueryOutput:		
                            if contextValue2 in d:
                                print("optj")
                                dialog_node = d[0]
                                dialog = d[1]
                                if "%%%%NLPERROR" in dialog:
                                    loc = dialog.find("%%%%NLPERROR")
                                    dialog = dialog[loc+12:]
                                parent_node =d[2]
                                condition =d[3]
                                entity_save =d[4]
                                break
                            else:
                                print("optk")
                                dialog_node = dbQueryOutput[0][0]
                                dialog = dbQueryOutput[0][1]
                                if "%%%%NLPERROR" in dialog:
                                    loc = dialog.find("%%%%NLPERROR")
                                    dialog = dialog[loc+12:]
                                parent_node =dbQueryOutput[0][2]
                                condition =dbQueryOutput[0][3]
                                entity_save =dbQueryOutput[0][4]
                    else:
                        # print("optl")
                        dialog_node = dbQueryOutput[0][0]
                        dialog = dbQueryOutput[0][1]
                        if "%%%%NLPERROR" in dialog:
                            loc = dialog.find("%%%%NLPERROR")
                            dialog = dialog[loc+12:]
                        parent_node =dbQueryOutput[0][2]
                        condition =dbQueryOutput[0][3]
                        entity_save =dbQueryOutput[0][4]

                else:
                    print("optm")
                    dialog_node,dialog,parent_node,condition,entity_save=switch_or_repeat(workspace,contextArr,entity,value,parent_node,entity_locale,intent_id,lang_id,confidence,inp)

            else:
                print("optn")
                pattern = re.compile(context_validation)
                patternMatch = pattern.match(inp)
                if patternMatch and "idexpiry" in context_name:
                    d1,m1,y1 = inp.split("-")
                    print("PPPPP ", d1,m1,y1)
                    if len(str(y1)) == 2:
                        y1 = int("20"+ str(y1))
                    if len(str(d1)) == 1:
                        d1 = int("0" + str(d1))
                    if len(str(m1)) == 1:
                        m1 = int("0" + str(m1))
                        print("y1",y1)
                    print("y11", y1)
                    print(d1,m1,y1," PPPPPP")
                    D1 = datetime.datetime(int(datetime.datetime.now().strftime("%Y")), int(datetime.datetime.now().strftime("%m")), int(datetime.datetime.now().strftime("%d")))
                    D2 = datetime.datetime(int(y1), int(m1), int(d1))
                    if D2 < D1:
                        print("opt_jj")	
                        sql = "{CALL dbo.getChildDialog (?)}"
                        params =  (parent_node)
                        dialogQuery = init.db_query(sql, params)	
                        if dialogQuery:
                            print("opt_kk")
                            dialog_node =  dialogQuery[0][0]
                            dialog =  dialogQuery[0][1]
                            if "%%%%NLPERRORPAST" in dialog:
                                loc = dialog.find("%%%%NLPERRORPAST")
                                loc1 = dialog.find("%%%%NLPERRORFORMAT")
                                print("LOCC", loc)
                                dialog = dialog[loc+16:loc1]
                                print("dialog",dialog)
                            # dialog = "^&*past"
                            # dialog =  dialogQuery[0][1]
                            parent_node = dialogQuery[0][2]
                            condition = dialogQuery[0][3]
                            entity_save =  dialogQuery[0][4]
                        else:
                            print("opt_ll")
                            dialog,dialog_node, parent_node, condition,entity_save = init.irrelevant(inp,workspace)
                    else:
                        print("opt_nn")
                        contextArr[context_name] =  inp
                        dialog_node =  dQuery[0][0]
                        dialog =  dQuery[0][1]
                        if "%%%%NLPERROR" in dialog:
                            loc = dialog.find("%%%%NLPERRORPAST")
                            dialog = dialog[:loc]
                        parent_node = dQuery[0][2]
                        condition = dQuery[0][3]
                        entity_save = dQuery[0][4]
                elif patternMatch:
                    # if patternMatch:
                    print("opto")
                    contextArr[context_name] = inp
                    dialog_node = dbQueryOutput[0][0]
                    dialog = dbQueryOutput[0][1]
                    if "%%%%NLPERROR" in dialog:
                        loc = dialog.find("%%%%NLPERROR")
                        dialog = dialog[:loc]
                    parent_node =dbQueryOutput[0][2]
                    condition =dbQueryOutput[0][3]
                    entity_save =dbQueryOutput[0][4]
                else:
                    print("optp")
                    dialog_node,dialog,parent_node,condition,entity_save=switch_or_repeat(workspace,contextArr,entity,value,parent_node,entity_locale,intent_id,lang_id,confidence,inp)
                    if "%%%%NLPERRORFORMAT" in dialog:
                        loc = dialog.find("%%%%NLPERRORFORMAT")
                        dialog = dialog[loc+18:]
                    elif "%%%%NLPERROR" in dialog:
                        loc = dialog.find("%%%%NLPERROR")
                        dialog = dialog[loc+12:]
                    else:
                        pass
    else:
        print("optq")
        dialog_node,dialog,parent_node,condition,entity_save=switch_or_repeat(workspace,contextArr,entity,value,parent_node,entity_locale,intent_id,lang_id,confidence,inp)
    if "%%%%NLPERROR" in dialog:
        loc = dialog.find("%%%%NLPERROR")
        dialog = dialog[loc+12:]
    return dialog_node,dialog,parent_node,condition,entity_save


def opt_(dQuery,workspace,contextArr,inp,parent_node,intent_id,lang_id,confidence):
    print("opt_a")
    null_context_variables = False
    conditionId =  dQuery[0][2]
    init= Funcs()
    print("datecheck1")
    print("dQuery", dQuery)
    print("workspace", workspace)
    print("contextArr", contextArr)
# 	print("entity", entity)
# 	print("value", value)
    print("inp", inp)
    print("parent_node", parent_node)
# 	print("entity_locale", entity_locale)
    print("intent_id", intent_id)
    print("lang_id", lang_id)
    print("confidence", confidence)

    if conditionId !=  '-1':
        print("opt_b")
        ContextnameParams =  (workspace,conditionId)
        ContextnameSql =  "{CALL dbo.getContextDetails(?,?)}"
        get_current_context =  init.db_query(ContextnameSql,ContextnameParams)
        context_name =  get_current_context[0][0]
        contextValue =  contextArr[context_name]
        print("context_name", context_name)
        print("contextValue", contextValue)
        if contextValue != "Null":
            print("opt_c")						
            for d in dQuery:							
                if contextValue in d:
                    print("opt_d")
                    dialog_node = d[0]
                    dialog = d[1]
                    if "%%%%NLPERROR" in dialog:
                        loc = dialog.find("%%%%NLPERROR")
                        dialog = dialog[loc+12:]
                    parent_node =d[2]
                    condition =d[3]
                    entity_save =d[4]
                    break
                else:
                    print("opt_e")
                    dialog_node = dQuery[0][0]
                    dialog = dQuery[0][1]
                    if "%%%%NLPERROR" in dialog:
                        loc = dialog.find("%%%%NLPERROR")
                        dialog = dialog[loc+12:]
                    parent_node =dQuery[0][2]
                    condition =dQuery[0][3]
                    entity_save =dQuery[0][4]
        else:
            print("opt_f")
            context_type = get_current_context[0][1]
            context_validation = get_current_context[0][2]	
            print("context_type", context_type)
            print("context_validation", context_validation)
            if "@entity" in context_validation:
                
                if confidence > 0.70:
                    print("opt_g")
                    sql =  "{CALL dbo.getIntentChildDialog (?,?,?)}"
                    parent_node_temp =  -1
                    params =  (intent_id,lang_id,parent_node_temp)
                    get_dialog =  init.db_query(sql, params)
                    if get_dialog:
                        print("opt_h")
                        entity = "no_entity"
                        value = "no_value"
                        entity_locale = "no_entity_locale"
                        dialog_node = get_dialog[0][0]
                        dialog = get_dialog[0][1]
                        if "%%%%NLPERROR" in dialog:
                            loc = dialog.find("%%%%NLPERROR")
                            dialog = dialog[loc+12:]
                        parent_node =get_dialog[0][2]
                        condition = get_dialog[0][3]
                        entity_save = False
                        null_context_variables = True
                    # else:
                    # 	print("opt_i")
                    # 	dialog,dialog_node, parent_node, condition,entity_save = init.irrelevant(inp,workspace)

                    else:
                        print("opt_j")	
                        sql = "{CALL dbo.getChildDialog (?)}"
                        params =  (parent_node)
                        dialogQuery = init.db_query(sql, params)	
                        if dialogQuery:
                            print("opt_k")
                            dialog_node =  dialogQuery[0][0]
                            dialog =  dialogQuery[0][1]
                            if "%%%%NLPERROR" in dialog:
                                loc = dialog.find("%%%%NLPERROR")
                                dialog = dialog[loc+12:]
                            parent_node = dialogQuery[0][2]
                            condition = dialogQuery[0][3]
                            entity_save =  dialogQuery[0][4]
                        else:
                            # print("opt_l")
                            dialog,dialog_node, parent_node, condition,entity_save = init.irrelevant(inp,workspace)
                else:
                    print("opt_j")	
                    sql = "{CALL dbo.getChildDialog (?)}"
                    params =  (parent_node)
                    dialogQuery = init.db_query(sql, params)	
                    if dialogQuery:
                        print("opt_k")
                        dialog_node =  dialogQuery[0][0]
                        dialog =  dialogQuery[0][1]
                        if "%%%%NLPERROR" in dialog:
                            loc = dialog.find("%%%%NLPERROR")
                            dialog = dialog[loc+12:]
                        parent_node = dialogQuery[0][2]
                        condition = dialogQuery[0][3]
                        entity_save =  dialogQuery[0][4]
                    else:
                        print("opt_l")
                        dialog,dialog_node, parent_node, condition,entity_save = init.irrelevant(inp,workspace)

                
            else:
                print("opt_m")
                pattern =  re.compile(context_validation)
                patternMatch =  pattern.match(inp)
                if patternMatch and "idexpiry" in context_name:
                    d1,m1,y1 = inp.split("-")
                    print("PPPPP ", d1,m1,y1)
                    if len(str(y1)) == 2:
                        y1 = int("20"+ str(y1))
                    if len(str(d1)) == 1:
                        d1 = int("0" + str(d1))
                    if len(str(m1)) == 1:
                        m1 = int("0" + str(m1))
                        print("y1",y1)
                    print("y11", y1)
                    # print(d1,m1,y1," PPPPPP")
                    D1 = datetime.datetime(int(datetime.datetime.now().strftime("%Y")), int(datetime.datetime.now().strftime("%m")), int(datetime.datetime.now().strftime("%d")))
                    D2 = datetime.datetime(int(y1), int(m1), int(d1))
                    if D2 < D1:
                        print("opt_jj")	
                        sql = "{CALL dbo.getChildDialog (?)}"
                        params =  (parent_node)
                        dialogQuery = init.db_query(sql, params)	
                        if dialogQuery:
                            print("opt_kk")
                            dialog_node =  dialogQuery[0][0]
                            dialog =  dialogQuery[0][1]
                            if "%%%%NLPERRORPAST" in dialog:
                                loc = dialog.find("%%%%NLPERRORPAST")
                                loc1 = dialog.find("%%%%NLPERRORFORMAT")
                                print("LOCC", loc)
                                dialog = dialog[loc+16:loc1]
                                print("dialog",dialog)
                            # dialog = "^&*past"
                            parent_node = dialogQuery[0][2]
                            condition = dialogQuery[0][3]
                            entity_save =  dialogQuery[0][4]
                        else:
                            print("opt_ll")
                            dialog,dialog_node, parent_node, condition,entity_save = init.irrelevant(inp,workspace)
                    else:
                        print("opt_nn")
                        contextArr[context_name] =  inp
                        dialog_node =  dQuery[0][0]
                        dialog =  dQuery[0][1]
                        if "%%%%NLPERROR" in dialog:
                            loc = dialog.find("%%%%NLPERRORPAST")
                            dialog = dialog[:loc]
                        parent_node = dQuery[0][2]
                        condition = dQuery[0][3]
                        entity_save = dQuery[0][4]
                elif patternMatch:
                    print("opt_n")
                    contextArr[context_name] =  inp
                    dialog_node =  dQuery[0][0]
                    dialog =  dQuery[0][1]
                    if "%%%%NLPERROR" in dialog:
                        loc = dialog.find("%%%%NLPERROR")
                        dialog = dialog[:loc]
                    parent_node = dQuery[0][2]
                    condition = dQuery[0][3]
                    entity_save = dQuery[0][4]
                else:
                    print("opt_o")
                    if confidence > 0.70:
                        print("opt_p")
                        sql =  "{CALL dbo.getIntentChildDialog (?,?,?)}"
                        parent_node_temp =  -1
                        params =  (intent_id,lang_id,parent_node_temp)
                        get_dialog =  init.db_query(sql, params)
                        if get_dialog:
                            print("opt_q")
                            entity =  "no_entity"
                            value =  "no_value"
                            entity_locale =  "no_entity_locale"
                            dialog_node =  get_dialog[0][0]
                            # dialog = "Entered date does not match the expected format.(dd-mm-yyyy)"
                            dialog =  get_dialog[0][1]
                            if "%%%%NLPERRORFORMAT" in dialog:
                                loc = dialog.find("%%%%NLPERRORFORMAT")
                                dialog = dialog[loc+18:]
                            elif "%%%%NLPERROR" in dialog:
                                loc = dialog.find("%%%%NLPERROR")
                                dialog = dialog[loc+12:]
                            else:
                                pass
                            parent_node = get_dialog[0][2]
                            condition =  get_dialog[0][3]
                            entity_save =  False
                            null_context_variables = True	
                        else:
                            print("opt_r")
                            sql = "{CALL dbo.getChildDialog (?)}"
                            params =  (parent_node)
                            dialogQuery = init.db_query(sql, params)	
                            if dialogQuery:
                                print("opt_s")
                                dialog_node = dialogQuery[0][0]
                                dialog = dialogQuery[0][1]
                                if "%%%%NLPERRORFORMAT" in dialog:
                                    loc = dialog.find("%%%%NLPERRORFORMAT")
                                    dialog = dialog[loc+18:]
                                elif "%%%%NLPERROR" in dialog:
                                    loc = dialog.find("%%%%NLPERROR")
                                    dialog = dialog[loc+12:]
                                else:
                                    pass
                                # dialog = "Entered date does not match the expected format.(dd-mm-yyyy)"
                                parent_node =dialogQuery[0][2]
                                condition =dialogQuery[0][3]
                                entity_save = dialogQuery[0][4]
                            else:
                                print("opt_t")
                                dialog,dialog_node, parent_node, condition,entity_save = init.irrelevant(inp,workspace)

                    else:
                        print("opt_u")	
                        sql = "{CALL dbo.getChildDialog (?)}"
                        params =  (parent_node)
                        dialogQuery = init.db_query(sql, params)	
                        if dialogQuery:
                            print("opt_v")
                            dialog_node = dialogQuery[0][0]
                            dialog = dialogQuery[0][1]
                            if "%%%%NLPERRORFORMAT" in dialog:
                                loc = dialog.find("%%%%NLPERRORFORMAT")
                                dialog = dialog[loc+18:]
                            elif "%%%%NLPERROR" in dialog:
                                loc = dialog.find("%%%%NLPERROR")
                                dialog = dialog[loc+12:]
                            else:
                                pass
                            parent_node =dialogQuery[0][2]
                            condition =dialogQuery[0][3]
                            entity_save = dialogQuery[0][4]
                        else:
                            print("opt_w")
                            dialog,dialog_node, parent_node, condition,entity_save = init.irrelevant(inp,workspace)
                            

            
    else:
        print("opt_x")
        dialog_node = dQuery[0][0]
        dialog = dQuery[0][1]
        if "%%%%NLPERROR" in dialog:
            loc = dialog.find("%%%%NLPERROR")
            dialog = dialog[loc+12:]
        parent_node =dQuery[0][2]
        condition =dQuery[0][3]
        entity_save =dQuery[0][4]
    if null_context_variables == True:
        print("opt_y")
        typeofcontext = "context" 
        get_current_context = init.db_query("select name from context where w_id =? and type=?",(workspace,typeofcontext))
        if get_current_context:
            for gc in get_current_context:
                currentContext = gc[0]					
                for key,value in contextArr.items():
                    if key == currentContext:
                        contextArr[key]="Null"

    print("dialogGG ", dialog)
    if "%%%%NLPERROR" in dialog:
        loc = dialog.find("%%%%NLPERROR")
        dialog = dialog[loc+12:]
    return dialog_node,dialog,parent_node,condition,entity_save

