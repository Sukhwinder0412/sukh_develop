from chatbase import MessageSet
from chatbase.base_message import Message
import requests
from datetime import datetime, date, timedelta
from db.services import conversation_service as conv_svc
import json
from presidio_analyzer import AnalyzerEngine
from presidio_anonymizer import AnonymizerEngine


analyzer = AnalyzerEngine()
anonymizer = AnonymizerEngine()

ts = str((datetime.today() - timedelta(minutes=10)).timestamp())
te = str(datetime.now().timestamp())


d = 1
# convs = conversations_request.json()
convs = json.loads(conv_svc.get_conversation(t1=ts, t2=te))
# print(json.loads(convs))
for x in convs:
    set = MessageSet(
        api_key="46e80185-8122-4f2c-aac9-db79eefea114",
        platform="Whatsapp",
        version="0.1",
        user_id=x["sender_id"],
    )
    for y in x["events"]:
        if y["event"] == "user":
            # print(y["parse_data"]["intent"]["name"])
            results = analyzer.analyze(text=y["text"], language="en")
            message = anonymizer.anonymize(text=y["text"], analyzer_results=results)
            # print(message)
            not_handled = (
                True if y["parse_data"]["intent"]["confidence"] <= 0.4 else False
            )
            print(not_handled)
            msg = Message(
                api_key="46e80185-8122-4f2c-aac9-db79eefea114",
                platform="Whatsapp",
                version="0.1",
                user_id=x["sender_id"],
                message=message,
                not_handled=not_handled,
                intent=y["parse_data"]["intent"]["name"],
                time_stamp=y["timestamp"],
                type="user",
            )
            set.append_message(msg)
            # print(set)
        elif y["event"] == "bot":
            results = analyzer.analyze(text=y["text"], language="en")
            message = anonymizer.anonymize(text=y["text"], analyzer_results=results)
            # print(message)
            msg = Message(
                api_key="46e80185-8122-4f2c-aac9-db79eefea114",
                platform="Whatsapp",
                version="0.1",
                user_id=x["sender_id"],
                message=message,
                time_stamp=y["timestamp"],
                # intent=y["parse_data"]["intent"]["name"],
                type="agent",
            )
            set.append_message(msg)
            # pass
            # print(y.keys())
            # print(y["text"], "-", y["parse_data"]["intent"]["name"])
    d += 1
resp = set.send()
# print(resp.json())
# print(y)
# print(y["event"])

# print(convs["data"][0]["events"][0].keys())