
## Whatsapp_numberBased
* #
  - utter_get_started
  - utter_menu1

> Whatsapp_numberBased__branches
## Whatsapp_numberBased__Mobile
> Whatsapp_numberBased__branches
* 1
  - utter_menu_mobile

> Whatsapp_numberBased__Mobile__branches
## Whatsapp_numberBased__Mobile__SHahry Postpaid
> Whatsapp_numberBased__Mobile__branches
* 1
  - utter_menu_shahry_postpaid

> Whatsapp_numberBased__Mobile__SHahry Postpaid__branches
## Whatsapp_numberBased__Mobile__SHahry Postpaid__Omanuna
> Whatsapp_numberBased__Mobile__SHahry Postpaid__branches
* 1
  - utter_omanuna
* FAQ
  - utter_FAQ

## Whatsapp_numberBased__Mobile__SHahry Postpaid__Shahry Endless
> Whatsapp_numberBased__Mobile__SHahry Postpaid__branches
* 2
  - utter_shahry_endless
* FAQ
  - utter_FAQ

## Whatsapp_numberBased__Mobile__Shababiah Prepaid
> Whatsapp_numberBased__Mobile__branches
* 2
  - utter_shababiah_prepaid

## Whatsapp_numberBased__Mobile__Popular services
> Whatsapp_numberBased__Mobile__branches
* 3
  - utter_popular_services

## Whatsapp_numberBased__Home
> Whatsapp_numberBased__branches
* 2
  - utter_menu_home

> Whatsapp_numberBased__Home__branches
## Whatsapp_numberBased__Home__5G Home Internet
> Whatsapp_numberBased__Home__branches
* 1
  - utter_5GHome

> Whatsapp_numberBased__Home__5G Home Internet__branches
## Whatsapp_numberBased__Home__5G Home Internet__5G Internet plans
> Whatsapp_numberBased__Home__5G Home Internet__branches
* 1
  - utter_5g_Plans

## Whatsapp_numberBased__Home__Fibre Home Internet
> Whatsapp_numberBased__Home__branches
* 2
  - utter_fibre_home

> Whatsapp_numberBased__Home__Fibre Home Internet__branches
## Whatsapp_numberBased__Home__Fibre Home Internet__Fibre_plans
> Whatsapp_numberBased__Home__Fibre Home Internet__branches
* 1
  - utter_fibre_plans

## Whatsapp_numberBased__Home__4G Home Internet
> Whatsapp_numberBased__Home__branches
* 3
  - utter_4GMenu
  - utter_menu_4g_home_internet

> Whatsapp_numberBased__Home__4G Home Internet__branches
## Whatsapp_numberBased__Home__4G Home Internet__4G_menu
> Whatsapp_numberBased__Home__4G Home Internet__branches
* 1
  - utter_4g_home_internet_plans

> Whatsapp_numberBased__Home__4G Home Internet__4G_menu__branches
## Whatsapp_numberBased__Home__4G Home Internet__4G_menu__More_4G_Plans
> Whatsapp_numberBased__Home__4G Home Internet__4G_menu__branches
## Whatsapp_numberBased__Home__4G Home Internet__More_4G_plans
> Whatsapp_numberBased__Home__4G Home Internet__branches
* 2
  - utter_more_4g

## Whatsapp_numberBased__SIM Services
> Whatsapp_numberBased__branches
* 3
  - utter_menu_sim_services

> Whatsapp_numberBased__SIM Services__branches
## Whatsapp_numberBased__SIM Services__SIM Replacement
> Whatsapp_numberBased__SIM Services__branches
* 1
  - utter_workflow_sim_replacement

## Whatsapp_numberBased__SIM Services__SIM Reactivations
> Whatsapp_numberBased__SIM Services__branches
* 2
  - utter_workflow_sim_reactivation

## Whatsapp_numberBased__Switch to ooredoo
> Whatsapp_numberBased__branches
* 4
  - utter_switch_to_ooredoo

## Whatsapp_numberBased__Promotions
> Whatsapp_numberBased__branches
* 5
  - utter_Promotions

## Whatsapp_numberBased__Pay+
> Whatsapp_numberBased__branches
* 6
  - utter_pay_plus

## Whatsapp_numberBased__language
> Whatsapp_numberBased__branches
* 9
  - action_language_change


## bored
* Bored
  - action_hello_world


## cant_sleep
* user.cantSleep
  - utter_user.cantSleep

