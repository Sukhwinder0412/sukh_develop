import requests
import json
import os
from db.to_markdown_parser import test_write_domain, test_write_nlu, test_write_stories


def model_train(languages, port):
    for language in languages:
        test_write_domain(languages)
    test_write_stories()
    domain = open("domain1.yml", "r")
    domain = domain.read().replace("'''", "'")
    domain = domain.replace("- type", "  type")
    domain = domain.replace("- -", "  -")
    with open("domain2.yml", "w") as g:
        g.write(domain)

    for language in languages:
        test_write_nlu(language)
    # print(domain)
    nlu = "\n\n"
    config_final = "\n"
    for language in languages:
        conf = f"language: {language}\n\n"
        nlu1 = open(f"nlu_{language}.md", "r")
        nlu = nlu + nlu1.read() + "\n\n"
        nlu1.close()
        config1 = open(f"config_{language}.yml", "r")
        config_final = config_final + conf + config1.read() + "\n\n"
        config1.close()

    with open("config.yml", "w") as g:
        g.write(config_final)
    with open("nlu.md", "w") as g:
        g.write(nlu)

    nlu = open("nlu.md", "r").read()
    config_final = open("config.yml", "r").read()

    stories = open("stories.md", "r")
    stories = stories.read()
    # print(stories)
    domain = (
        domain
        + "\nsession_config:\n  session_expiration_time: 2\n  carry_over_slots_to_new_session: false"
    )
    #   - name: "SpacyNLP"\n  - name: "SpacyTokenizer"\n  - name: "SpacyFeaturizer"\n  - name: "RegexFeaturizer"\n  - name: "CRFEntityExtractor"\n  - name: "EntitySynonymMapper"\n  - name: "SklearnIntentClassifier"
    # if languages[0] == "en":
    #     url = "http://nlp.kochartech.com:5005/model/train"
    #     url_replace = "http://nlp.kochartech.com:5005/model"
    #     # fname = "./models/"
    # else:
    #     url = "http://nlp.kochartech.com:5006/model/train"
    #     url_replace = "http://nlp.kochartech.com:5006/model"
    #     # fname = "./models/"

    url = f"https://nlp.kochartech.com:{port}/model"

    payload = {
        "domain": domain,
        "nlu": nlu,
        "stories": stories,
        "config": config_final,
        "force": True,
    }
    headers = {"Content-Type": "application/json"}
    # print(payload)
    response = requests.request("POST", url, headers=headers, data=json.dumps(payload))
    rasa_location = "/home/ubuntu/rasa/rasa/"
    filename = response.headers["filename"]
    os.rename(f"{rasa_location}{filename}", f"{rasa_location}{language}-{filename}")

    return str(response.status_code), 200
